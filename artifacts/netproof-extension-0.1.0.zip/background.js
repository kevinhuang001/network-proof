var Pr = Object.defineProperty;
var Kr = (e, t, n) => t in e ? Pr(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n;
var l = (e, t, n) => Kr(e, typeof t != "symbol" ? t + "" : t, n);
class ut extends Error {
  constructor(n, r, o) {
    super(r);
    l(this, "code");
    l(this, "details");
    this.name = "NetProofError", this.code = n, this.details = o;
  }
}
const re = BigInt(2 ** 32 - 1), dn = /* @__PURE__ */ BigInt(32);
function qr(e, t = !1) {
  return t ? { h: Number(e & re), l: Number(e >> dn & re) } : { h: Number(e >> dn & re) | 0, l: Number(e & re) | 0 };
}
function Pn(e, t = !1) {
  const n = e.length;
  let r = new Uint32Array(n), o = new Uint32Array(n);
  for (let i = 0; i < n; i++) {
    const { h: s, l: c } = qr(e[i], t);
    [r[i], o[i]] = [s, c];
  }
  return [r, o];
}
const jr = (e) => e / 2 ** 32 | 0, Yr = (e) => e >>> 0;
function Zr(e, t, n, r) {
  const o = jr(n), i = Yr(n);
  e.setUint32(t, r ? i : o, r), e.setUint32(t + 4, r ? o : i, r);
}
const un = (e, t, n) => e >>> n, ln = (e, t, n) => e << 32 - n | t >>> n, St = (e, t, n) => e >>> n | t << 32 - n, Ot = (e, t, n) => e << 32 - n | t >>> n, ie = (e, t, n) => e << 64 - n | t >>> n - 32, oe = (e, t, n) => e >>> n - 32 | t << 64 - n;
function at(e, t, n, r) {
  const o = (t >>> 0) + (r >>> 0);
  return { h: e + n + (o / 2 ** 32 | 0) | 0, l: o | 0 };
}
const zr = (e, t, n) => (e >>> 0) + (t >>> 0) + (n >>> 0), Xr = (e, t, n, r) => t + n + r + (e / 2 ** 32 | 0) | 0, Gr = (e, t, n, r) => (e >>> 0) + (t >>> 0) + (n >>> 0) + (r >>> 0), Wr = (e, t, n, r, o) => t + n + r + o + (e / 2 ** 32 | 0) | 0, Vr = (e, t, n, r, o) => (e >>> 0) + (t >>> 0) + (n >>> 0) + (r >>> 0) + (o >>> 0), Jr = (e, t, n, r, o, i) => t + n + r + o + i + (e / 2 ** 32 | 0) | 0;
function He(e) {
  return e instanceof Uint8Array || ArrayBuffer.isView(e) && e.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in e && e.BYTES_PER_ELEMENT === 1;
}
const he = (e) => e ? `"${e}" ` : "";
function V(e, t = "") {
  if (typeof e != "number")
    throw new TypeError(he(t) + "expected number, got " + typeof e);
  if (!Number.isSafeInteger(e) || e < 0)
    throw new RangeError(he(t) + "expected integer >= 0, got " + e);
  return e;
}
function Qr(e, t = "") {
  if (typeof e != "boolean")
    throw new TypeError(he(t) + "expected boolean, got type=" + typeof e);
  return e;
}
function Y(e, t, n = "") {
  if (He(e) && (t === void 0 || e.length === t))
    return e;
  t !== void 0 && V(t, "length");
  const r = He(e), o = t !== void 0 ? ` of length ${t}` : "", i = r ? `length=${e.length}` : `type=${typeof e}`, s = he(n) + "expected Uint8Array" + o + ", got " + i;
  throw r ? new RangeError(s) : new TypeError(s);
}
function Kn(e) {
  if (typeof e != "function" || typeof e.create != "function")
    throw new TypeError("expected hash wrapped by utils.createHasher");
  if (V(e.outputLen), V(e.blockLen), e.outputLen < 1 || e.blockLen < 1)
    throw new Error("hash blockLen / outputLen must be >= 1");
}
const ti = (e, t) => {
  if (e === null || typeof e != "object" || Array.isArray(e))
    throw new TypeError((t === "object" ? "" : `"${t}" `) + "expected object, got type=" + typeof e);
}, hn = (e, t) => {
  ti(e, t);
  const n = Object.getPrototypeOf(e);
  if (n !== Object.prototype && n !== null)
    throw new TypeError(`"${t}" expected plain object`);
  if (Object.hasOwn(e, "__proto__"))
    throw new TypeError(`"${t}.__proto__" is not allowed`);
};
function Dt(e, t = !0) {
  if (e.destroyed)
    throw new Error("hash was destroyed");
  if (t && e.finished)
    throw new Error("digest() was already called");
}
function Me(e, t) {
  Y(e, void 0, "output");
  const n = t.outputLen;
  if (!(e.length >= n))
    throw new RangeError('"output" expected length >= ' + n);
}
function pn(e) {
  return new Uint32Array(e.buffer, e.byteOffset, Math.floor(e.byteLength / 4));
}
function lt(...e) {
  for (let t = 0; t < e.length; t++)
    e[t].fill(0);
}
function Nt(e) {
  return new DataView(e.buffer, e.byteOffset, e.byteLength);
}
function rt(e, t) {
  return e << 32 - t | e >>> t;
}
function se(e, t) {
  return e << t | e >>> 32 - t >>> 0;
}
const ei = new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68;
function ni(e) {
  return e << 24 & 4278190080 | e << 8 & 16711680 | e >>> 8 & 65280 | e >>> 24 & 255;
}
function ri(e) {
  for (let t = 0; t < e.length; t++)
    e[t] = ni(e[t]);
  return e;
}
const wn = ei ? (e) => e : ri, qn = /* @ts-ignore */ typeof Uint8Array.from([]).toHex == "function" && typeof Uint8Array.fromHex == "function", ii = /* @__PURE__ */ Array.from({ length: 256 }, (e, t) => t.toString(16).padStart(2, "0"));
function Pe(e) {
  if (Y(e), qn)
    return e.toHex();
  let t = "";
  for (let n = 0; n < e.length; n++)
    t += ii[e[n]];
  return t;
}
function gn(e) {
  return e >= 48 && e <= 57 ? e - 48 : e >= 65 && e <= 70 ? e - 55 : e >= 97 && e <= 102 ? e - 87 : void 0;
}
function jn(e) {
  if (typeof e != "string")
    throw new TypeError("hex string expected, got " + typeof e);
  if (qn)
    try {
      return Uint8Array.fromHex(e);
    } catch (o) {
      throw o instanceof SyntaxError ? new RangeError(o.message) : o;
    }
  const t = e.length, n = t / 2;
  if (t % 2)
    throw new RangeError("hex string expected, got unpadded hex of length " + t);
  const r = new Uint8Array(n);
  for (let o = 0, i = 0; o < n; o++, i += 2) {
    const s = gn(e.charCodeAt(i)), c = gn(e.charCodeAt(i + 1));
    if (s === void 0 || c === void 0) {
      const a = e[i] + e[i + 1];
      throw new RangeError('hex string expected, got non-hex character "' + a + '" at index ' + i);
    }
    r[o] = s * 16 + c;
  }
  return r;
}
function Yt(...e) {
  let t = 0;
  for (let r = 0; r < e.length; r++) {
    const o = e[r];
    Y(o), t += o.length;
  }
  const n = new Uint8Array(t);
  for (let r = 0, o = 0; r < e.length; r++) {
    const i = e[r];
    n.set(i, o), o += i.length;
  }
  return n;
}
function oi(e, t, n = "opts") {
  return hn(e, "defaults"), t !== void 0 && hn(t, n), Object.assign(/* @__PURE__ */ Object.create(null), e, t);
}
function ge(e, t = {}) {
  if (typeof e != "function")
    throw new TypeError('"hashCons" expected function, got type=' + typeof e);
  t = oi({}, t, "info");
  const n = (o, i) => e(i).update(o).digest(), r = e(void 0);
  return n.outputLen = r.outputLen, n.blockLen = r.blockLen, n.canXOF = r.canXOF, n.create = (o) => e(o), Object.assign(n, t), Object.freeze(n);
}
function si(e = 32) {
  V(e, "bytesLength");
  const t = typeof globalThis == "object" ? globalThis.crypto : null;
  if (typeof (t == null ? void 0 : t.getRandomValues) != "function")
    throw new Error("crypto.getRandomValues must be defined");
  if (e > 65536)
    throw new RangeError(`"bytesLength" expected <= 65536, got ${e}`);
  return t.getRandomValues(new Uint8Array(e));
}
const Yn = (e) => ({
  // Current NIST hashAlgs suffixes used here fit in one DER subidentifier octet.
  // Larger suffix values would need base-128 OID encoding and a different length byte.
  oid: Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2, e])
});
function ci(e, t, n) {
  return e & t ^ ~e & n;
}
function ai(e, t, n) {
  return e & t ^ e & n ^ t & n;
}
class Ke {
  constructor(t, n, r, o) {
    l(this, "blockLen");
    l(this, "outputLen");
    l(this, "canXOF", !1);
    l(this, "padOffset");
    l(this, "isLE");
    // For partial updates less than block size
    l(this, "buffer");
    l(this, "view");
    l(this, "finished", !1);
    l(this, "length", 0);
    l(this, "pos", 0);
    l(this, "destroyed", !1);
    this.blockLen = t, this.outputLen = n, this.padOffset = r, this.isLE = o, this.buffer = new Uint8Array(t), this.view = Nt(this.buffer);
  }
  update(t) {
    Dt(this), Y(t);
    const { view: n, buffer: r, blockLen: o } = this, i = t.length;
    let s = !1;
    for (let c = 0; c < i; ) {
      const a = Math.min(o - this.pos, i - c);
      if (a === o) {
        const f = Nt(t);
        for (; o <= i - c; c += o)
          this.process(f, c);
        s = !0;
        continue;
      }
      r.set(c === 0 && a === i ? t : t.subarray(c, c + a), this.pos), this.pos += a, c += a, this.pos === o && (this.process(n, 0), this.pos = 0, s = !0);
    }
    return this.length += t.length, s && this.roundClean(), this;
  }
  digestInto(t) {
    Dt(this), Me(t, this), this.finished = !0;
    const { buffer: n, view: r, blockLen: o, isLE: i } = this;
    let { pos: s } = this;
    n[s++] = 128, n.fill(0, s), this.padOffset > o - s && (this.process(r, 0), n.fill(0)), Zr(r, o - 8, this.length * 8, i), this.process(r, 0), this.roundClean();
    const c = t === n ? r : Nt(t), a = this.outputLen, f = a / 4, d = this.get();
    if (a % 4 || f > d.length)
      throw new Error("invalid outputLen");
    for (let w = 0; w < f; w++)
      c.setUint32(4 * w, d[w], i);
  }
  digest() {
    const { buffer: t, outputLen: n } = this;
    this.digestInto(t);
    const r = t.slice(0, n);
    return this.destroy(), r;
  }
  _cloneIntoMeta(t) {
    const { buffer: n, length: r, finished: o, destroyed: i, pos: s } = this;
    return t.destroyed = i, t.finished = o, t.length = r, t.pos = s, s && t.buffer.set(n), t;
  }
  clone() {
    return this._cloneInto();
  }
}
const fi = /* @__PURE__ */ Uint32Array.from([
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
]), di = /* @__PURE__ */ Uint32Array.from([
  1779033703,
  4089235720,
  3144134277,
  2227873595,
  1013904242,
  4271175723,
  2773480762,
  1595750129,
  1359893119,
  2917565137,
  2600822924,
  725511199,
  528734635,
  4215389547,
  1541459225,
  327033209
]), ui = /* @__PURE__ */ Uint32Array.from([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]), wt = /* @__PURE__ */ new Uint32Array(64);
class li extends Ke {
  constructor(n, r) {
    super(64, n, 8, !1);
    // We cannot use array here since array allows indexing by variable
    // which means optimizer/compiler cannot use registers.
    // Numeric initializers matter: starting the fields as `undefined` changes
    // V8's field representation and makes sha256 3x slower (measured).
    l(this, "A", 0);
    l(this, "B", 0);
    l(this, "C", 0);
    l(this, "D", 0);
    l(this, "E", 0);
    l(this, "F", 0);
    l(this, "G", 0);
    l(this, "H", 0);
    this.A = r[0] | 0, this.B = r[1] | 0, this.C = r[2] | 0, this.D = r[3] | 0, this.E = r[4] | 0, this.F = r[5] | 0, this.G = r[6] | 0, this.H = r[7] | 0;
  }
  get() {
    const { A: n, B: r, C: o, D: i, E: s, F: c, G: a, H: f } = this;
    return [n, r, o, i, s, c, a, f];
  }
  // prettier-ignore
  set(n, r, o, i, s, c, a, f) {
    this.A = n | 0, this.B = r | 0, this.C = o | 0, this.D = i | 0, this.E = s | 0, this.F = c | 0, this.G = a | 0, this.H = f | 0;
  }
  _cloneInto(n) {
    return (n || (n = new this.constructor())).set(...this.get()), this._cloneIntoMeta(n);
  }
  process(n, r) {
    for (let p = 0; p < 16; p++, r += 4)
      wt[p] = n.getUint32(r, !1);
    for (let p = 16; p < 64; p++) {
      const g = wt[p - 15], h = wt[p - 2], E = rt(g, 7) ^ rt(g, 18) ^ g >>> 3, x = rt(h, 17) ^ rt(h, 19) ^ h >>> 10;
      wt[p] = x + wt[p - 7] + E + wt[p - 16] | 0;
    }
    let { A: o, B: i, C: s, D: c, E: a, F: f, G: d, H: w } = this;
    for (let p = 0; p < 64; p++) {
      const g = rt(a, 6) ^ rt(a, 11) ^ rt(a, 25), h = w + g + ci(a, f, d) + ui[p] + wt[p] | 0, x = (rt(o, 2) ^ rt(o, 13) ^ rt(o, 22)) + ai(o, i, s) | 0;
      w = d, d = f, f = a, a = c + h | 0, c = s, s = i, i = o, o = h + x | 0;
    }
    o = o + this.A | 0, i = i + this.B | 0, s = s + this.C | 0, c = c + this.D | 0, a = a + this.E | 0, f = f + this.F | 0, d = d + this.G | 0, w = w + this.H | 0, this.set(o, i, s, c, a, f, d, w);
  }
  roundClean() {
    lt(wt);
  }
  destroy() {
    this.destroyed = !0, this.set(0, 0, 0, 0, 0, 0, 0, 0), lt(this.buffer);
  }
}
class hi extends li {
  constructor() {
    super(32, fi);
  }
}
const Zn = Pn([
  "0x428a2f98d728ae22",
  "0x7137449123ef65cd",
  "0xb5c0fbcfec4d3b2f",
  "0xe9b5dba58189dbbc",
  "0x3956c25bf348b538",
  "0x59f111f1b605d019",
  "0x923f82a4af194f9b",
  "0xab1c5ed5da6d8118",
  "0xd807aa98a3030242",
  "0x12835b0145706fbe",
  "0x243185be4ee4b28c",
  "0x550c7dc3d5ffb4e2",
  "0x72be5d74f27b896f",
  "0x80deb1fe3b1696b1",
  "0x9bdc06a725c71235",
  "0xc19bf174cf692694",
  "0xe49b69c19ef14ad2",
  "0xefbe4786384f25e3",
  "0x0fc19dc68b8cd5b5",
  "0x240ca1cc77ac9c65",
  "0x2de92c6f592b0275",
  "0x4a7484aa6ea6e483",
  "0x5cb0a9dcbd41fbd4",
  "0x76f988da831153b5",
  "0x983e5152ee66dfab",
  "0xa831c66d2db43210",
  "0xb00327c898fb213f",
  "0xbf597fc7beef0ee4",
  "0xc6e00bf33da88fc2",
  "0xd5a79147930aa725",
  "0x06ca6351e003826f",
  "0x142929670a0e6e70",
  "0x27b70a8546d22ffc",
  "0x2e1b21385c26c926",
  "0x4d2c6dfc5ac42aed",
  "0x53380d139d95b3df",
  "0x650a73548baf63de",
  "0x766a0abb3c77b2a8",
  "0x81c2c92e47edaee6",
  "0x92722c851482353b",
  "0xa2bfe8a14cf10364",
  "0xa81a664bbc423001",
  "0xc24b8b70d0f89791",
  "0xc76c51a30654be30",
  "0xd192e819d6ef5218",
  "0xd69906245565a910",
  "0xf40e35855771202a",
  "0x106aa07032bbd1b8",
  "0x19a4c116b8d2d0c8",
  "0x1e376c085141ab53",
  "0x2748774cdf8eeb99",
  "0x34b0bcb5e19b48a8",
  "0x391c0cb3c5c95a63",
  "0x4ed8aa4ae3418acb",
  "0x5b9cca4f7763e373",
  "0x682e6ff3d6b2b8a3",
  "0x748f82ee5defb2fc",
  "0x78a5636f43172f60",
  "0x84c87814a1f0ab72",
  "0x8cc702081a6439ec",
  "0x90befffa23631e28",
  "0xa4506cebde82bde9",
  "0xbef9a3f7b2c67915",
  "0xc67178f2e372532b",
  "0xca273eceea26619c",
  "0xd186b8c721c0c207",
  "0xeada7dd6cde0eb1e",
  "0xf57d4f7fee6ed178",
  "0x06f067aa72176fba",
  "0x0a637dc5a2c898a6",
  "0x113f9804bef90dae",
  "0x1b710b35131c471b",
  "0x28db77f523047d84",
  "0x32caab7b40c72493",
  "0x3c9ebe0a15c9bebc",
  "0x431d67c49c100d4c",
  "0x4cc5d4becb3e42b6",
  "0x597f299cfc657e2a",
  "0x5fcb6fab3ad6faec",
  "0x6c44198c4a475817"
].map((e) => BigInt(e))), pi = Zn[0], wi = Zn[1], gt = /* @__PURE__ */ new Uint32Array(80), bt = /* @__PURE__ */ new Uint32Array(80);
class gi extends Ke {
  constructor(n, r) {
    super(128, n, 16, !1);
    // We cannot use array here since array allows indexing by variable
    // which means optimizer/compiler cannot use registers.
    // h -- high 32 bits, l -- low 32 bits
    // Numeric initializers matter: starting the fields as `undefined` changes
    // V8's field representation and slows hashing down (measured on sha256).
    l(this, "Ah", 0);
    l(this, "Al", 0);
    l(this, "Bh", 0);
    l(this, "Bl", 0);
    l(this, "Ch", 0);
    l(this, "Cl", 0);
    l(this, "Dh", 0);
    l(this, "Dl", 0);
    l(this, "Eh", 0);
    l(this, "El", 0);
    l(this, "Fh", 0);
    l(this, "Fl", 0);
    l(this, "Gh", 0);
    l(this, "Gl", 0);
    l(this, "Hh", 0);
    l(this, "Hl", 0);
    this.Ah = r[0] | 0, this.Al = r[1] | 0, this.Bh = r[2] | 0, this.Bl = r[3] | 0, this.Ch = r[4] | 0, this.Cl = r[5] | 0, this.Dh = r[6] | 0, this.Dl = r[7] | 0, this.Eh = r[8] | 0, this.El = r[9] | 0, this.Fh = r[10] | 0, this.Fl = r[11] | 0, this.Gh = r[12] | 0, this.Gl = r[13] | 0, this.Hh = r[14] | 0, this.Hl = r[15] | 0;
  }
  // prettier-ignore
  get() {
    const { Ah: n, Al: r, Bh: o, Bl: i, Ch: s, Cl: c, Dh: a, Dl: f, Eh: d, El: w, Fh: p, Fl: g, Gh: h, Gl: E, Hh: x, Hl: I } = this;
    return [n, r, o, i, s, c, a, f, d, w, p, g, h, E, x, I];
  }
  // prettier-ignore
  set(n, r, o, i, s, c, a, f, d, w, p, g, h, E, x, I) {
    this.Ah = n | 0, this.Al = r | 0, this.Bh = o | 0, this.Bl = i | 0, this.Ch = s | 0, this.Cl = c | 0, this.Dh = a | 0, this.Dl = f | 0, this.Eh = d | 0, this.El = w | 0, this.Fh = p | 0, this.Fl = g | 0, this.Gh = h | 0, this.Gl = E | 0, this.Hh = x | 0, this.Hl = I | 0;
  }
  _cloneInto(n) {
    return (n || (n = new this.constructor())).set(...this.get()), this._cloneIntoMeta(n);
  }
  process(n, r) {
    for (let O = 0; O < 16; O++, r += 4)
      gt[O] = n.getUint32(r), bt[O] = n.getUint32(r += 4);
    for (let O = 16; O < 80; O++) {
      const P = gt[O - 15] | 0, L = bt[O - 15] | 0, K = St(P, L, 1) ^ St(P, L, 8) ^ un(P, L, 7), ot = Ot(P, L, 1) ^ Ot(P, L, 8) ^ ln(P, L, 7), j = gt[O - 2] | 0, D = bt[O - 2] | 0, st = St(j, D, 19) ^ ie(j, D, 61) ^ un(j, D, 6), et = Ot(j, D, 19) ^ oe(j, D, 61) ^ ln(j, D, 6), nt = Gr(ot, et, bt[O - 7], bt[O - 16]), ht = Wr(nt, K, st, gt[O - 7], gt[O - 16]);
      gt[O] = ht | 0, bt[O] = nt | 0;
    }
    let { Ah: o, Al: i, Bh: s, Bl: c, Ch: a, Cl: f, Dh: d, Dl: w, Eh: p, El: g, Fh: h, Fl: E, Gh: x, Gl: I, Hh: C, Hl: M } = this;
    for (let O = 0; O < 80; O++) {
      const P = St(p, g, 14) ^ St(p, g, 18) ^ ie(p, g, 41), L = Ot(p, g, 14) ^ Ot(p, g, 18) ^ oe(p, g, 41), K = p & h ^ ~p & x, ot = g & E ^ ~g & I, j = Vr(M, L, ot, wi[O], bt[O]), D = Jr(j, C, P, K, pi[O], gt[O]), st = j | 0, et = St(o, i, 28) ^ ie(o, i, 34) ^ ie(o, i, 39), nt = Ot(o, i, 28) ^ oe(o, i, 34) ^ oe(o, i, 39), ht = o & s ^ o & a ^ s & a, ct = i & c ^ i & f ^ c & f;
      C = x | 0, M = I | 0, x = h | 0, I = E | 0, h = p | 0, E = g | 0, { h: p, l: g } = at(d | 0, w | 0, D | 0, st | 0), d = a | 0, w = f | 0, a = s | 0, f = c | 0, s = o | 0, c = i | 0;
      const Et = zr(st, nt, ct);
      o = Xr(Et, D, et, ht), i = Et | 0;
    }
    ({ h: o, l: i } = at(this.Ah | 0, this.Al | 0, o | 0, i | 0)), { h: s, l: c } = at(this.Bh | 0, this.Bl | 0, s | 0, c | 0), { h: a, l: f } = at(this.Ch | 0, this.Cl | 0, a | 0, f | 0), { h: d, l: w } = at(this.Dh | 0, this.Dl | 0, d | 0, w | 0), { h: p, l: g } = at(this.Eh | 0, this.El | 0, p | 0, g | 0), { h, l: E } = at(this.Fh | 0, this.Fl | 0, h | 0, E | 0), { h: x, l: I } = at(this.Gh | 0, this.Gl | 0, x | 0, I | 0), { h: C, l: M } = at(this.Hh | 0, this.Hl | 0, C | 0, M | 0), this.set(o, i, s, c, a, f, d, w, p, g, h, E, x, I, C, M);
  }
  roundClean() {
    lt(gt, bt);
  }
  destroy() {
    this.destroyed = !0, lt(this.buffer), this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
  }
}
class bi extends gi {
  constructor() {
    super(64, di);
  }
}
const qe = /* @__PURE__ */ ge(
  () => new hi(),
  /* @__PURE__ */ Yn(1)
), bn = /* @__PURE__ */ ge(
  () => new bi(),
  /* @__PURE__ */ Yn(3)
), yi = new TextEncoder();
new TextDecoder();
function mi(e) {
  return yi.encode(e);
}
const yn = "0123456789abcdef";
function be(e, t = !1) {
  let n = t ? "0x" : "";
  for (let r = 0; r < e.length; r++)
    n += yn[e[r] >> 4] + yn[e[r] & 15];
  return n;
}
(() => {
  const e = new Uint32Array(256);
  for (let t = 0; t < 256; t++) {
    let n = t;
    for (let r = 0; r < 8; r++) n = n & 1 ? 3988292384 ^ n >>> 1 : n >>> 1;
    e[t] = n >>> 0;
  }
  return e;
})();
mi("netproof-wallet/entropy/v1");
class mn {
  constructor(t, n) {
    l(this, "oHash");
    l(this, "iHash");
    l(this, "blockLen");
    l(this, "outputLen");
    l(this, "canXOF", !1);
    l(this, "finished", !1);
    l(this, "destroyed", !1);
    if (Kn(t), Y(n, void 0, "key"), this.iHash = t.create(), typeof this.iHash.update != "function")
      throw new Error("expected Hash instance");
    this.blockLen = this.iHash.blockLen, this.outputLen = this.iHash.outputLen;
    const r = this.blockLen, o = new Uint8Array(r);
    o.set(n.length > r ? t.create().update(n).digest() : n);
    for (let i = 0; i < o.length; i++)
      o[i] ^= 54;
    this.iHash.update(o), this.oHash = t.create();
    for (let i = 0; i < o.length; i++)
      o[i] ^= 106;
    this.oHash.update(o), lt(o);
  }
  update(t) {
    return Dt(this), this.iHash.update(t), this;
  }
  digestInto(t) {
    Dt(this), Me(t, this), this.finished = !0;
    const n = t.subarray(0, this.outputLen);
    this.iHash.digestInto(n), this.oHash.update(n), this.oHash.digestInto(n), this.destroy();
  }
  digest() {
    const t = new Uint8Array(this.oHash.outputLen);
    return this.digestInto(t), t;
  }
  _cloneInto(t) {
    t || (t = Object.create(Object.getPrototypeOf(this), {}));
    const { oHash: n, iHash: r, finished: o, destroyed: i, blockLen: s, outputLen: c, canXOF: a } = this;
    return t = t, t.finished = o, t.destroyed = i, t.blockLen = s, t.outputLen = c, t.canXOF = a, t.oHash = n._cloneInto(t.oHash), t.iHash = r._cloneInto(t.iHash), t;
  }
  clone() {
    return this._cloneInto();
  }
  destroy() {
    this.destroyed = !0, this.oHash.destroy(), this.iHash.destroy();
  }
}
const Le = /* @__PURE__ */ (() => {
  const e = ((t, n, r) => new mn(t, n).update(r).digest());
  return e.create = (t, n) => new mn(t, n), e;
})();
function zn(e, t, n = () => {
}) {
  if (!Array.isArray(e))
    throw new TypeError(`"${t}" expected array, got type=${typeof e}`);
  for (let r = 0; r < e.length; r++)
    n(e[r], `${t}[${r}]`);
  return e;
}
const Z = (e, t, n) => Y(e, t, n), Xn = V;
function xi(e, t = "") {
  if (typeof e != "string") {
    const n = t && `"${t}" `;
    throw new TypeError(n + "expected string, got type=" + typeof e);
  }
  return e;
}
function Ft(e, t = "object") {
  if (e === null || typeof e != "object" || Array.isArray(e))
    throw new TypeError(t === "object" ? "expected valid options object" : `"${t}" expected object, got type=${typeof e}`);
  return e;
}
function zt(e, t) {
  if (typeof e != "function")
    throw new TypeError(`"${t}" is invalid: expected function, got ${typeof e}`);
  return e;
}
const Gn = Pe, mt = (...e) => Yt(...e), Ue = (e) => jn(e), ye = He, je = (e) => si(e), pe = /* @__PURE__ */ BigInt(0), xn = /* @__PURE__ */ BigInt(1), Ei = (e) => e ? `"${e}" ` : "";
function It(e, t = "") {
  if (typeof e != "boolean")
    throw new TypeError(Ei(t) + "expected boolean, got type=" + typeof e);
  return e;
}
function Ye(e) {
  if (typeof e == "bigint") {
    if (!_t(e))
      throw new RangeError("positive bigint expected, got " + e);
  } else
    Xn(e);
  return e;
}
function Gt(e, t = "") {
  if (typeof e != "number") {
    const n = t && `"${t}" `;
    throw new TypeError(n + "expected number, got type=" + typeof e);
  }
  if (!Number.isSafeInteger(e)) {
    const n = t && `"${t}" `;
    throw new RangeError(n + "expected safe integer, got " + e);
  }
}
function ce(e) {
  const t = Ye(e).toString(16);
  return t.length & 1 ? "0" + t : t;
}
function Wn(e) {
  if (typeof e != "string")
    throw new TypeError("hex string expected, got " + typeof e);
  return e === "" ? pe : BigInt("0x" + e);
}
function kt(e) {
  return Wn(Pe(e));
}
function Vn(e) {
  return Wn(Pe(vi(Y(e)).reverse()));
}
function Ze(e, t) {
  if (V(t), t === 0)
    throw new Error("zero output length is invalid");
  e = Ye(e);
  const n = t * 2, r = e.toString(16);
  if (r.length > n)
    throw new RangeError("number is too large");
  return jn(r.padStart(n, "0"));
}
function Jn(e, t) {
  return Ze(e, t).reverse();
}
function vi(e) {
  return Uint8Array.from(Z(e));
}
function _t(e) {
  return typeof e == "bigint" && pe <= e;
}
function Qn(e, t, n) {
  return _t(e) && _t(t) && _t(n) && t <= e && e < n;
}
function tr(e, t, n, r) {
  if (!Qn(t, n, r))
    throw new RangeError("expected valid " + e + ": " + n + " <= n < " + r + ", got " + t);
}
function ze(e) {
  if (e < pe)
    throw new Error("expected non-negative bigint, got " + e);
  return e === pe ? 0 : e.toString(2).length;
}
const Xe = (e) => (Gt(e, "n"), (xn << BigInt(e)) - xn);
function Ai(e, t, n) {
  if (V(e, "hashLen"), V(t, "qByteLen"), typeof n != "function")
    throw new TypeError("hmacFn must be a function");
  const r = (x) => new Uint8Array(x), o = Uint8Array.of(), i = Uint8Array.of(0), s = Uint8Array.of(1), c = 1e3;
  let a = r(e), f = r(e), d = 0;
  const w = () => {
    a.fill(1), f.fill(0), d = 0;
  }, p = (...x) => n(f, mt(a, ...x)), g = (x = o) => {
    f = p(i, x), a = p(), x.length !== 0 && (f = p(s, x), a = p());
  }, h = () => {
    if (d++ >= c)
      throw new Error("drbg: tried max amount of iterations");
    let x = 0;
    const I = [];
    for (; x < t; ) {
      a = p();
      const C = a.slice();
      I.push(C), x += a.length;
    }
    return mt(...I);
  };
  return (x, I) => {
    w(), g(x);
    let C;
    for (; (C = I(h())) === void 0; )
      g();
    return w(), C;
  };
}
function ee(e, t = {}, n = {}, r = "object") {
  Ft(e, r), Ft(t, "fields"), Ft(n, "optFields");
  function o(s, c, a) {
    const f = r === "object" ? `param "${String(s)}"` : `"${r}.${String(s)}"`, d = e[s];
    if (!Object.hasOwn(e, s) && (a ? d !== void 0 : c !== "function"))
      throw new TypeError(`${f} is invalid: expected own property`);
    if (a && d === void 0)
      return;
    const w = typeof d;
    if (w !== c || d === null)
      throw new TypeError(`${f} is invalid: expected ${c}, got ${w}`);
  }
  const i = (s, c) => Object.entries(s).forEach(([a, f]) => o(a, f, c));
  i(t, !1), i(n, !0);
}
const $ = /* @__PURE__ */ BigInt(0), U = /* @__PURE__ */ BigInt(1), xt = /* @__PURE__ */ BigInt(2), er = /* @__PURE__ */ BigInt(3), Ge = /* @__PURE__ */ BigInt(4), nr = /* @__PURE__ */ BigInt(5), _i = /* @__PURE__ */ BigInt(7), rr = /* @__PURE__ */ BigInt(8), Bi = /* @__PURE__ */ BigInt(9), Ii = /* @__PURE__ */ BigInt(15), ir = /* @__PURE__ */ BigInt(16), Ri = /* @__PURE__ */ BigInt("0x10000000000000000");
function J(e, t) {
  if (t <= $)
    throw new Error("mod: expected positive modulus, got " + t);
  const n = e % t;
  return n >= $ ? n : t + n;
}
function or(e, t, n) {
  if (n <= U)
    throw new Error("pow: expected modulus > 1, got " + n);
  if (typeof t != "bigint")
    throw new TypeError("invalid exponent: expected bigint, got " + typeof t);
  if (t < $)
    throw new Error("invalid exponent, negatives unsupported");
  if (t === $)
    return U;
  if (t === U)
    return e;
  let r = e % n;
  if (r < $ && (r += n), t < Ri) {
    let c = U;
    for (; t > $; )
      t & U && (c = c * r % n), r = r * r % n, t >>= U;
    return c;
  }
  const o = [];
  for (; t > $; )
    o.push(Number(t & Ii)), t >>= Ge;
  const i = new Array(16);
  i[0] = U, i[1] = r;
  for (let c = 2; c < 16; c++)
    i[c] = i[c - 1] * r % n;
  let s = i[o[o.length - 1]];
  for (let c = o.length - 2; c >= 0; c--) {
    s = s * s % n, s = s * s % n, s = s * s % n, s = s * s % n;
    const a = o[c];
    a !== 0 && (s = s * i[a] % n);
  }
  return s;
}
function tt(e, t, n) {
  if (n <= U)
    throw new Error("pow2: expected modulus > 1, got " + n);
  if (t < $)
    throw new Error("pow2: expected non-negative exponent, got " + t);
  let r = e;
  for (; t-- > $; )
    r *= r, r %= n;
  return r;
}
function En(e, t) {
  if (e === $)
    throw new Error("invert: expected non-zero number");
  if (t <= U)
    throw new Error("invert: expected modulus > 1, got " + t);
  let n = J(e, t), r = t, o = $, i = U;
  for (; n !== $; ) {
    const c = r / n, a = r - n * c, f = o - i * c;
    r = n, n = a, o = i, i = f;
  }
  if (r !== U)
    throw new Error("invert: does not exist");
  return J(o, t);
}
function Si(e, t) {
  if (t <= U)
    throw new Error("invertCt: expected prime modulus > 1, got " + t);
  const n = J(e, t);
  if (n === $)
    throw new Error("invertCt: expected non-zero number");
  const r = or(n, t - xt, t);
  if (J(n * r, t) !== U)
    throw new Error("invertCt: does not exist");
  return r;
}
function We(e, t, n) {
  const r = e;
  if (!r.eql(r.sqr(t), n))
    throw new Error("Cannot find square root");
}
function Ve(e, t) {
  if ((e & U) === $)
    throw new Error(t + ": expected odd modulus, got " + e);
}
function sr(e, t) {
  const n = e, r = (n.ORDER + U) / Ge, o = n.pow(t, r);
  return We(n, o, t), o;
}
function Oi(e, t) {
  const n = e, r = (n.ORDER - nr) / rr, o = n.mul(t, xt), i = n.pow(o, r), s = n.mul(t, i), c = n.mul(n.mul(s, xt), i), a = n.mul(s, n.sub(c, n.ONE));
  return We(n, a, t), a;
}
function Ti(e) {
  const t = me(e), n = cr(e), r = n(t, t.neg(t.ONE)), o = n(t, r), i = n(t, t.neg(r)), s = (e + _i) / ir;
  return ((c, a) => {
    const f = c;
    let d = f.pow(a, s), w = f.mul(d, r);
    const p = f.mul(d, o), g = f.mul(d, i), h = f.eql(f.sqr(w), a), E = f.eql(f.sqr(p), a);
    d = f.cmov(d, w, h), w = f.cmov(g, p, E);
    const x = f.eql(f.sqr(w), a), I = f.cmov(d, w, x);
    return We(f, I, a), I;
  });
}
function cr(e) {
  if (e < er)
    throw new Error("sqrt is not defined for small field");
  Ve(e, "tonelliShanks");
  let t = e - U, n = 0;
  for (; t % xt === $; )
    t /= xt, n++;
  let r = xt;
  const o = me(e);
  for (; vn(o, r) === 1; )
    if (r++ > 1e3)
      throw new Error("Cannot find square root: probably non-prime P");
  if (n === 1)
    return sr;
  let i = o.pow(r, t);
  const s = (t + U) / xt;
  return function(a, f) {
    const d = a;
    if (d.is0(f))
      return f;
    if (vn(d, f) !== 1)
      throw new Error("Cannot find square root");
    let w = n, p = d.mul(d.ONE, i), g = d.pow(f, t), h = d.pow(f, s);
    for (; !d.eql(g, d.ONE); ) {
      if (d.is0(g))
        throw new Error("Cannot find square root: probably non-prime P");
      let E = 1, x = d.sqr(g);
      for (; !d.eql(x, d.ONE); )
        if (E++, x = d.sqr(x), E === w)
          throw new Error("Cannot find square root");
      const I = U << BigInt(w - E - 1), C = d.pow(p, I);
      w = E, p = d.sqr(C), g = d.mul(g, p), h = d.mul(h, C);
    }
    return h;
  };
}
function Ci(e) {
  return Ve(e, "Fp.sqrt"), e % Ge === er ? sr : e % rr === nr ? Oi : e % ir === Bi ? Ti(e) : cr(e);
}
const Hi = [
  "create",
  "isValid",
  "is0",
  "neg",
  "inv",
  "sqrt",
  "sqr",
  "eql",
  "add",
  "sub",
  "mul",
  "pow",
  "div",
  "addN",
  "subN",
  "mulN",
  "sqrN"
];
function Wt(e) {
  if (Ft(e, "field"), typeof e.ORDER != "bigint")
    throw new TypeError('param "ORDER" is invalid: expected bigint, got ' + typeof e.ORDER);
  Gt(e.BYTES, "BYTES"), Gt(e.BITS, "BITS");
  for (const t of Hi)
    zt(e[t], "field." + t);
  if (e.BYTES < 1 || e.BITS < 1)
    throw new Error("invalid field: expected BYTES/BITS > 0");
  if (e.ORDER <= U)
    throw new Error("invalid field: expected ORDER > 1, got " + e.ORDER);
  return e;
}
function ar(e, t, n = !1) {
  Wt(e), zn(t, "nums"), It(n, "passZero");
  const r = e, o = new Array(t.length).fill(n ? r.ZERO : void 0), i = t.reduce((c, a, f) => r.is0(a) ? c : (o[f] = c, r.mul(c, a)), r.ONE), s = r.inv(i);
  return t.reduceRight((c, a, f) => r.is0(a) ? c : (o[f] = r.mul(c, o[f]), r.mul(c, a)), s), o;
}
function vn(e, t) {
  Wt(e);
  const n = e;
  Ve(n.ORDER, "FpLegendre");
  const r = (n.ORDER - U) / xt, o = n.pow(t, r), i = n.eql(o, n.ONE), s = n.eql(o, n.ZERO), c = n.eql(o, n.neg(n.ONE));
  if (!i && !s && !c)
    throw new Error("invalid Legendre symbol result");
  return i ? 1 : s ? 0 : -1;
}
function Li(e, t) {
  if (t !== void 0 && Xn(t), e <= $)
    throw new Error("invalid n length: expected positive n, got " + e);
  if (t !== void 0 && t < 1)
    throw new Error("invalid n length: expected positive bit length, got " + t);
  const n = ze(e);
  if (t !== void 0 && t < n)
    throw new Error(`invalid n length: expected nBitLength (${t}) >= bitLen(n) (${n})`);
  const r = t !== void 0 ? t : n, o = Math.ceil(r / 8);
  return { nBitLength: r, nByteLength: o };
}
const An = /* @__PURE__ */ new WeakMap();
class _n {
  constructor(t, n = {}) {
    l(this, "ORDER");
    l(this, "BITS");
    l(this, "BYTES");
    l(this, "isLE");
    l(this, "ZERO", $);
    l(this, "ONE", U);
    l(this, "_lengths");
    l(this, "_mod");
    if (t <= U)
      throw new Error("invalid field: expected ORDER > 1, got " + t);
    let r;
    this.isLE = !1, n != null && typeof n == "object" && (typeof n.BITS == "number" && (r = n.BITS), typeof n.sqrt == "function" && Object.defineProperty(this, "sqrt", { value: n.sqrt, enumerable: !0 }), typeof n.isLE == "boolean" && (this.isLE = n.isLE), n.allowedLengths && (this._lengths = Object.freeze(n.allowedLengths.slice())), typeof n.modFromBytes == "boolean" && (this._mod = n.modFromBytes));
    const { nBitLength: o, nByteLength: i } = Li(t, r);
    if (i > 2048)
      throw new Error("invalid field: expected ORDER of <= 2048 bytes");
    this.ORDER = t, this.BITS = o, this.BYTES = i, Object.freeze(this);
  }
  create(t) {
    return J(t, this.ORDER);
  }
  isValid(t) {
    if (typeof t != "bigint")
      throw new TypeError("invalid field element: expected bigint, got " + typeof t);
    return $ <= t && t < this.ORDER;
  }
  is0(t) {
    return t === $;
  }
  // is valid and invertible
  isValidNot0(t) {
    return !this.is0(t) && this.isValid(t);
  }
  isOdd(t) {
    return (t & U) === U;
  }
  neg(t) {
    return J(-t, this.ORDER);
  }
  eql(t, n) {
    return t === n;
  }
  sqr(t) {
    return J(t * t, this.ORDER);
  }
  add(t, n) {
    return J(t + n, this.ORDER);
  }
  sub(t, n) {
    return J(t - n, this.ORDER);
  }
  mul(t, n) {
    return J(t * n, this.ORDER);
  }
  pow(t, n) {
    return or(t, n, this.ORDER);
  }
  div(t, n) {
    return J(t * En(n, this.ORDER), this.ORDER);
  }
  // Same as above, but doesn't normalize
  sqrN(t) {
    return t * t;
  }
  addN(t, n) {
    return t + n;
  }
  subN(t, n) {
    return t - n;
  }
  mulN(t, n) {
    return t * n;
  }
  inv(t) {
    return En(t, this.ORDER);
  }
  sqrt(t) {
    let n = An.get(this);
    return n || An.set(this, n = Ci(this.ORDER)), n(this, t);
  }
  toBytes(t) {
    return this.isLE ? Jn(t, this.BYTES) : Ze(t, this.BYTES);
  }
  fromBytes(t, n = !1) {
    Z(t);
    const { _lengths: r, BYTES: o, isLE: i, ORDER: s, _mod: c } = this;
    if (r) {
      if (t.length < 1 || !r.includes(t.length) || t.length > o)
        throw new Error("Field.fromBytes: expected " + r + " bytes, got " + t.length);
      const f = new Uint8Array(o);
      f.set(t, i ? 0 : f.length - t.length), t = f;
    }
    if (t.length !== o)
      throw new Error("Field.fromBytes: expected " + o + " bytes, got " + t.length);
    let a = i ? Vn(t) : kt(t);
    if (c && (a = J(a, s)), !n && !this.isValid(a))
      throw new Error("invalid field element: outside of range 0..ORDER");
    return a;
  }
  // TODO: we don't need it here, move out to separate fn
  invertBatch(t) {
    return ar(this, t, !0);
  }
  // We can't move this out because Fp6, Fp12 implement it
  // and it's unclear what to return in there.
  cmov(t, n, r) {
    return It(r, "condition"), r ? n : t;
  }
}
function me(e, t = {}) {
  return Object.freeze(_n.prototype), new _n(e, t);
}
function fr(e) {
  if (typeof e != "bigint")
    throw new Error("field order must be bigint");
  if (e <= U)
    throw new Error("field order must be greater than 1");
  const t = ze(e - U);
  return Math.ceil(t / 8);
}
function Je(e) {
  const t = fr(e);
  return t + Math.ceil(t / 2);
}
function dr(e, t, n = !1) {
  Z(e);
  const r = e.length, o = fr(t), i = Math.max(Je(t), 16);
  if (r < i || r > 1024)
    throw new Error("expected " + i + "-1024 bytes of input, got " + r);
  const s = n ? Vn(e) : kt(e), c = J(s, t - U) + U;
  return n ? Jn(c, o) : Ze(c, o);
}
const Qe = /* @__PURE__ */ BigInt(0), Vt = /* @__PURE__ */ BigInt(1), Ui = /* @__PURE__ */ BigInt(4), ve = 16, Bn = 128, Ni = 5, In = 2 ** 31;
function ne(e) {
  const t = e;
  if (typeof t != "function")
    throw new TypeError('"Point" expected constructor, got type=' + typeof e);
  zt(t.fromAffine, "Point.fromAffine"), zt(t.fromBytes, "Point.fromBytes"), zt(t.fromHex, "Point.fromHex"), Ft(t.BASE, "Point.BASE"), Ft(t.ZERO, "Point.ZERO"), Wt(t.Fp), Wt(t.Fn);
}
function Fi(e, t) {
  ne(e), lr(t, e);
  const n = ar(e.Fp, t.map((r) => r.Z));
  return t.map((r, o) => e.fromAffine(r.toAffine(n[o])));
}
function Di(e, t, n = 1) {
  if (!Number.isSafeInteger(e) || e < n || e > t)
    throw new Error("invalid window size, expected [" + n + ".." + t + "], got W=" + e);
}
function ki(e, t) {
  const n = e * (4 * t + 128);
  if (n > In)
    throw new Error("invalid window size: table would need ~" + Math.ceil(n / 2 ** 20) + " MiB, max " + In / 2 ** 20 + " MiB");
}
function ur(e, t) {
  if (e !== void 0) {
    zt(e, "randomBytes");
    try {
      const n = e(t);
      if (!ye(n) || n.length !== t)
        return;
    } catch {
      return;
    }
    return e;
  }
}
function lr(e, t) {
  zn(e, "points"), e.forEach((n, r) => {
    if (!(n instanceof t))
      throw new Error("invalid point at index " + r);
  });
}
function $i(e, t, n) {
  if (!Array.isArray(e))
    throw new Error("array of scalars expected");
  e.forEach((r, o) => {
    if (!(n === void 0 ? t.isValid(r) : _t(r) && r < n))
      throw new Error("invalid scalar at index " + o);
  });
}
const hr = /* @__PURE__ */ new WeakMap();
function Ae(e) {
  return hr.get(e) || 1;
}
function Mi(e, t) {
  const n = e.double(), r = [e];
  for (let o = 1; o < t; o++)
    r.push(r[o - 1].add(n));
  return r;
}
function Pi(e, t) {
  const n = 2 ** t, r = n / 2, o = BigInt(n - 1), i = [];
  for (; e > Qe; ) {
    let s = 0;
    e & Vt && (s = Number(e & o), s >= r && (s -= n), e -= BigInt(s)), i.push(s), e >>= Vt;
  }
  return i;
}
function Ki(e, t, n) {
  const r = 2 ** t, o = r / 2, i = BigInt(r - 1), s = BigInt(t), c = [];
  for (let a = 0; a < n; a++) {
    let f = Number(e & i);
    e >>= s, f > o && (f -= r, e += Vt), c.push(f);
  }
  if (e !== Qe)
    throw new Error("invalid wnaf");
  return c;
}
function qi(e, t, n) {
  let r = 0;
  for (const i of n)
    r = Math.max(r, i.length);
  let o = e;
  for (let i = r - 1; i >= 0; i--) {
    i !== r - 1 && (o = o.double());
    for (let s = 0; s < n.length; s++) {
      const c = n[s][i];
      if (c) {
        const a = t[s][Math.abs(c) - 1 >> 1];
        o = o.add(c < 0 ? a.negate() : a);
      }
    }
  }
  return o;
}
class ji {
  // Parametrized with a given Point class (not individual point)
  constructor(t, n) {
    l(this, "Point");
    l(this, "BASE");
    l(this, "ZERO");
    l(this, "randomBytes");
    l(this, "wnafPrecomputes", /* @__PURE__ */ new WeakMap());
    l(this, "baseCanBeBlinded");
    l(this, "bits");
    ne(t), this.randomBytes = ur(n, ve), this.Point = t, this.BASE = t.BASE, this.ZERO = t.ZERO, this.bits = t.Fn.BITS;
  }
  /**
   * Creates a signed fixed-window wNAF precomputation table: for every window w, the
   * multiples `[1..2^(W−1)]⋅2^(w⋅W)⋅P`, flattened. All doublings are baked into the table,
   * so cached multiplication is additions-only. `windows = ceil(bits/W) + 1`: the extra
   * window absorbs the final carry of signed-digit recoding.
   * For a 256-bit curve and W=6, the table is 44⋅32 = 1408 points.
   * @param point - Point instance
   * @param W - window size
   * @param bits - scalar bitlength the table must cover
   */
  buildWnafTable(t, n, r) {
    const o = Math.ceil(r / n) + 1, i = 2 ** (n - 1), s = [];
    let c = t;
    for (let a = 0; a < o; a++) {
      let f = c;
      for (let d = 0; d < i; d++)
        s.push(f), f = f.add(c);
      c = s[s.length - 1].double();
    }
    return { W: n, bits: r, windows: o, comp: s };
  }
  /**
   * Implements ec multiplication using precomputed signed fixed-window wNAF tables.
   * Constant-time: fixed window count with one table addition per window — zero digits feed
   * the fake accumulator — and no doublings; the lookup scans the whole window slice.
   * Scalar bounds are validated by the public entry points ({@link ScalarMultiplier.mulCT},
   * {@link ScalarMultiplier.mulCTBlinded}, {@link ScalarMultiplier.mulUnsafe});
   * signedWindowDigits throws if `n` exceeds the table.
   * @returns real and fake (for const-time) points
   */
  wnafCachedCT(t, n) {
    const { W: r, windows: o, comp: i } = t, s = 2 ** (r - 1), c = Ki(n, r, o);
    let a = this.ZERO, f = this.BASE;
    for (let d = 0; d < o; d++) {
      const w = c[d], p = d * s, g = Math.abs(w) - 1;
      let h = i[p];
      for (let x = 1; x < s; x++)
        h = x === g ? i[p + x] : h;
      const E = h.negate();
      w === 0 ? f = f.add(i[p]) : a = a.add(w < 0 ? E : h);
    }
    return { p: a, f };
  }
  // Cache key is point identity plus (W, bits); at most two entries exist per point (public-width
  // `Fn.BITS` and blinded `Fn.BITS + BLIND_BITS`). Callers must not reuse the same point with
  // incompatible `transform(...)` layouts and expect a separate cache entry.
  getWnafPrecomputes(t, n, r, o) {
    let i = this.wnafPrecomputes.get(n), s = i == null ? void 0 : i.find((c) => c.W === t && c.bits === r);
    return s || (s = this.buildWnafTable(n, t, r), typeof o == "function" && (s = { ...s, comp: o(s.comp) }), i || (i = [], this.wnafPrecomputes.set(n, i)), i.push(s)), s;
  }
  assertPoint(t) {
    if (!(t instanceof this.Point))
      throw new TypeError('"point" expected Point instance, got type=' + typeof t);
  }
  // Shared prologue of the constant-time entry points. Rejects scalar 0: in key/signature-style
  // callers a zero scalar means broken upstream plumbing, and concrete Points already reject it.
  // Uses inRange instead of Fn.isValidNot0: validateField() only certifies the arithmetic subset.
  validateMulInput(t, n) {
    if (this.assertPoint(t), !Qn(n, Vt, this.Point.Fn.ORDER))
      throw new Error("invalid scalar");
  }
  // Constant-time dispatch shared by mulCT / mulCTBlinded. Un-precomputed points (W===1, e.g.
  // ECDH peer keys) skip building a throwaway cached table in favor of a small fixed-window
  // multiply. `n` must be < 2^bits.
  runCT(t, n, r, o) {
    const i = Ae(t);
    return i === 1 ? this.fixedWindowCT(t, n, r) : this.wnafCachedCT(this.getWnafPrecomputes(i, t, r, o), n);
  }
  mulCT(t, n, r) {
    return this.validateMulInput(t, n), this.runCT(t, n, this.bits, r);
  }
  mulCTBlinded(t, n, r) {
    if (this.validateMulInput(t, n), this.randomBytes === void 0)
      throw new Error("randomBytes is required for scalar blinding");
    const o = this.Point.Fn.BITS + Bn, i = this.randomBytes(ve);
    if (!ye(i) || i.length !== ve)
      throw new Error("randomBytes returned invalid byte array");
    i[0] = i[0] & 63 | 128;
    const s = n + kt(i) * this.Point.Fn.ORDER;
    return this.runCT(t, s, o, r);
  }
  /**
   * Constant-time multiplication `n*point` for an un-precomputed point, via a small fixed window.
   * A cached wNAF table only pays off when reused; a flat 2^FW_WINDOW table (`size-1` adds) is
   * far cheaper to build for a single use. The point-operation sequence is independent of `n`:
   * build the table, then per window exactly FW_WINDOW doublings, a data-oblivious scan over
   * every table entry, and one addition (adds the identity when the window digit is 0 — never
   * skipped).
   *
   * `n` must be `< 2^bits`. Assumes complete addition (adding the identity costs the same as any
   * add), which holds for the Weierstrass/Edwards point types used here. The table is left in
   * projective form (no normalizeZ): normalizing this small a table costs more than the
   * mixed-add savings it would buy for a single multiply.
   * @returns real point `p`; `f` duplicates it only to match {@link wnafCachedCT}'s return shape
   * (this path needs no fake accumulator — its op-count is already scalar-independent).
   */
  fixedWindowCT(t, n, r) {
    const o = Ni, i = 1 << o, s = Xe(o), c = new Array(i);
    c[0] = this.ZERO;
    for (let d = 1; d < i; d++)
      c[d] = c[d - 1].add(t);
    const a = Math.ceil(r / o);
    let f = this.ZERO;
    for (let d = a - 1; d >= 0; d--) {
      if (d !== a - 1)
        for (let g = 0; g < o; g++)
          f = f.double();
      const w = Number(n >> BigInt(d * o) & s);
      let p = c[0];
      for (let g = 1; g < i; g++)
        p = g === w ? c[g] : p;
      f = f.add(p);
    }
    return { p: f, f };
  }
  shouldBlind(t, n) {
    return this.randomBytes === void 0 ? !1 : n === Vt ? !0 : t !== this.BASE ? !1 : (this.baseCanBeBlinded === void 0 && (this.baseCanBeBlinded = this.mulUnsafe(this.BASE, this.Point.Fn.ORDER).is0()), this.baseCanBeBlinded);
  }
  mulSecret(t, n, r, o) {
    return this.shouldBlind(t, r) ? this.mulCTBlinded(t, n, o) : this.mulCT(t, n, o);
  }
  mulUnsafe(t, n, r) {
    if (this.assertPoint(t), !_t(n))
      throw new Error("invalid scalar");
    const o = Ae(t);
    if (o === 1 || n >= this.Point.Fn.ORDER)
      return Ne(this.Point, [t], [n], !0);
    const i = this.getWnafPrecomputes(o, t, this.bits, r);
    return this.wnafCachedCT(i, n).p;
  }
  // Remembers the window size used for precomputed wNAF multiplication of the given point
  // and drops any previously built tables. Usually only the base point is precomputed.
  // W=1 resets the point to the un-precomputed (table-less) paths.
  // W is additionally capped so tables stay under ~2 GiB ({@link TABLE_BYTES_MAX}).
  setWindowSize(t, n) {
    this.assertPoint(t), Di(n, this.bits);
    const r = Math.ceil((this.bits + Bn) / n) + 1;
    ki(r * 2 ** (n - 1), this.Point.Fp.BYTES), hr.set(t, n), this.wnafPrecomputes.delete(t);
  }
  // True when a window size is set: tables themselves are built lazily on first multiply.
  hasWindowSize(t) {
    return Ae(t) !== 1;
  }
}
function Ne(e, t, n, r = !1) {
  if (ne(e), lr(t, e), It(r, "allowOversized"), $i(n, e.Fn, r ? e.Fn.ORDER ** Ui : void 0), t.length !== n.length)
    throw new Error("arrays of points and scalars must have equal length");
  const o = t.map((s) => Mi(s, 4)), i = n.map((s) => Pi(s, 4));
  return qi(e.ZERO, o, i);
}
function Rn(e, t, n) {
  if (t) {
    if (t.ORDER !== e)
      throw new Error("Field.ORDER must match order: Fp == p, Fn == n");
    return Wt(t), t;
  } else
    return me(e, { isLE: n });
}
function Yi(e, t, n = {}, r) {
  if (r === void 0 && (r = e === "edwards"), !t || typeof t != "object")
    throw new Error(`expected valid ${e} CURVE object`);
  ee(n);
  for (const a of ["p", "n", "h"]) {
    const f = t[a];
    if (!(_t(f) && f !== Qe))
      throw new Error(`CURVE.${a} must be positive bigint`);
  }
  const o = Rn(t.p, n.Fp, r), i = Rn(t.n, n.Fn, r), c = ["Gx", "Gy", "a", "b"];
  for (const a of c)
    if (!o.isValid(t[a]))
      throw new Error(`CURVE.${a} must be valid field element of CURVE.Fp`);
  return t = Object.freeze(Object.assign({}, t)), { CURVE: t, Fp: o, Fn: i };
}
function Zi(e, t) {
  return function(r) {
    const o = e(r);
    return { secretKey: o, publicKey: t(o) };
  };
}
const zi = /* @__PURE__ */ BigInt(0);
class Xi extends Error {
  constructor(t = "") {
    super(t);
  }
}
const ft = {
  // asn.1 DER encoding utils
  Err: Xi,
  // Basic building block is TLV (Tag-Length-Value)
  _tlv: {
    encode: (e, t) => {
      const { Err: n } = ft;
      if (Gt(e, "tag"), e < 0 || e > 255)
        throw new n("tlv.encode: wrong tag");
      if (xi(t, "data"), t.length & 1)
        throw new n("tlv.encode: unpadded data");
      const r = t.length / 2, o = ce(r);
      if (o.length / 2 & 128)
        throw new n("tlv.encode: long form length too big");
      const i = r > 127 ? ce(o.length / 2 | 128) : "";
      return ce(e) + i + o + t;
    },
    // v - value, l - left bytes (unparsed)
    decode(e, t) {
      const { Err: n } = ft;
      t = Z(t, void 0, "DER data");
      let r = 0;
      if (e < 0 || e > 255)
        throw new n("tlv.decode: wrong tag");
      if (t.length < 2 || t[r++] !== e)
        throw new n("tlv.decode: wrong tlv");
      const o = t[r++], i = !!(o & 128);
      let s = 0;
      if (!i)
        s = o;
      else {
        const a = o & 127;
        if (!a)
          throw new n("tlv.decode(long): indefinite length not supported");
        if (a > 4)
          throw new n("tlv.decode(long): byte length is too big");
        const f = t.subarray(r, r + a);
        if (f.length !== a)
          throw new n("tlv.decode: length bytes not complete");
        if (f[0] === 0)
          throw new n("tlv.decode(long): zero leftmost byte");
        for (const d of f)
          s = s << 8 | d;
        if (r += a, s < 128)
          throw new n("tlv.decode(long): not minimal encoding");
      }
      const c = t.subarray(r, r + s);
      if (c.length !== s)
        throw new n("tlv.decode: wrong value length");
      return { v: c, l: t.subarray(r + s) };
    }
  },
  // https://crypto.stackexchange.com/a/57734 Leftmost bit of first byte is 'negative' flag,
  // since we always use positive integers here. It must always be empty:
  // - add zero byte if exists
  // - if next byte doesn't have a flag, leading zero is not allowed (minimal encoding)
  _int: {
    encode(e) {
      const { Err: t } = ft;
      if (Ye(e), e < zi)
        throw new t("integer: negative integers are not allowed");
      let n = ce(e);
      if (Number.parseInt(n[0], 16) & 8 && (n = "00" + n), n.length & 1)
        throw new t("unexpected DER parsing assertion: unpadded hex");
      return n;
    },
    decode(e) {
      const { Err: t } = ft;
      if (e.length < 1)
        throw new t("invalid signature integer: empty");
      if (e[0] & 128)
        throw new t("invalid signature integer: negative");
      if (e.length > 1 && e[0] === 0 && !(e[1] & 128))
        throw new t("invalid signature integer: unnecessary leading zero");
      return kt(e);
    }
  },
  toSig(e, t) {
    const { Err: n, _int: r, _tlv: o } = ft;
    if (t !== void 0 && (Gt(t, "maxScalarBytes"), t < 1))
      throw new n("invalid signature: maxScalarBytes must be positive");
    const i = Z(e, void 0, "signature"), { v: s, l: c } = o.decode(48, i);
    if (c.length)
      throw new n("invalid signature: left bytes after parsing");
    const { v: a, l: f } = o.decode(2, s), { v: d, l: w } = o.decode(2, f);
    if (w.length)
      throw new n("invalid signature: left bytes after parsing");
    if (t !== void 0 && (a.length > t || d.length > t))
      throw new n("invalid signature: integer too large");
    return { r: r.decode(a), s: r.decode(d) };
  },
  hexFromSig(e) {
    const { _tlv: t, _int: n } = ft;
    ee(e, { r: "bigint", s: "bigint" }, {}, "sig");
    const r = t.encode(2, n.encode(e.r)), o = t.encode(2, n.encode(e.s)), i = r + o;
    return t.encode(48, i);
  }
}, _e = (Object.freeze(ft._tlv), Object.freeze(ft._int), Object.freeze(ft));
const Sn = (e, t) => (e + (e >= 0 ? t : -t) / pr) / t;
function Gi(e, t, n) {
  tr("scalar", e, dt, n);
  const [[r, o], [i, s]] = t, c = Sn(s * e, n), a = Sn(-o * e, n);
  let f = e - c * r - a * i, d = -c * o - a * s;
  const w = f < dt, p = d < dt;
  w && (f = -f), p && (d = -d);
  const g = Xe(Math.ceil(ze(n) / 2)) + At;
  if (f < dt || f >= g || d < dt || d >= g)
    throw new Error("splitScalar (endomorphism): failed for k");
  return { k1neg: w, k1: f, k2neg: p, k2: d };
}
function Fe(e) {
  if (!["compact", "recovered", "der"].includes(e))
    throw new Error('Signature format must be "compact", "recovered", or "der"');
  return e;
}
function Be(e, t) {
  ee(e);
  const n = {};
  for (let r of Object.keys(t))
    n[r] = e[r] === void 0 ? t[r] : e[r];
  return It(n.lowS, "lowS"), It(n.prehash, "prehash"), n.format !== void 0 && Fe(n.format), n;
}
const dt = /* @__PURE__ */ BigInt(0), At = /* @__PURE__ */ BigInt(1), pr = /* @__PURE__ */ BigInt(2), Ie = /* @__PURE__ */ BigInt(3), Wi = /* @__PURE__ */ BigInt(4);
function Vi(e, t = {}) {
  const n = Yi("weierstrass", e, t), r = n.Fp, o = n.Fn;
  let i = n.CURVE;
  const { h: s, n: c } = i;
  ee(t, {}, {
    allowInfinityPoint: "boolean",
    clearCofactor: "function",
    isTorsionFree: "function",
    fromBytes: "function",
    toBytes: "function",
    endo: "object",
    randomBytes: "function"
  });
  const { endo: a, allowInfinityPoint: f, clearCofactor: d, isTorsionFree: w, fromBytes: p, toBytes: g } = t, h = t.randomBytes === void 0 ? je : t.randomBytes;
  if (a && (!r.is0(i.a) || typeof a.beta != "bigint" || !Array.isArray(a.basises)))
    throw new Error('invalid endo: expected "beta": bigint and "basises": array');
  const E = a ? {
    beta: a.beta,
    basises: a.basises.map((b) => [...b])
  } : void 0, x = gr(r, o);
  function I() {
    if (!r.isOdd)
      throw new Error("compression is not supported: Field does not have .isOdd()");
  }
  function C(b, u, y) {
    if (u.is0()) {
      if (!f)
        throw new Error("bad point: ZERO");
      return Uint8Array.of(0);
    }
    const { x: m, y: _ } = u.toAffine(), B = r.toBytes(m);
    if (It(y, "isCompressed"), y) {
      I();
      const v = !r.isOdd(_);
      return mt(wr(v), B);
    } else
      return mt(Uint8Array.of(4), B, r.toBytes(_));
  }
  function M(b) {
    Z(b, void 0, "Point");
    const { publicKey: u, publicKeyUncompressed: y } = x, m = b.length, _ = b[0], B = b.subarray(1);
    if (f && m === 1 && _ === 0)
      return { x: r.ZERO, y: r.ZERO };
    if (m === u && (_ === 2 || _ === 3)) {
      const v = r.fromBytes(B);
      if (!r.isValid(v))
        throw new Error("bad point: is not on curve, wrong x");
      const S = ot(v);
      let R;
      try {
        R = r.sqrt(S);
      } catch (N) {
        const k = N instanceof Error ? ": " + N.message : "";
        throw new Error("bad point: is not on curve, sqrt error" + k);
      }
      I();
      const H = r.isOdd(R);
      return (_ & 1) === 1 !== H && (R = r.neg(R)), { x: v, y: R };
    } else if (m === y && _ === 4) {
      const v = r.BYTES, S = r.fromBytes(B.subarray(0, v)), R = r.fromBytes(B.subarray(v, v * 2));
      if (!j(S, R))
        throw new Error("bad point: is not on curve");
      return { x: S, y: R };
    } else
      throw new Error(`bad point: got length ${m}, expected compressed=${u} or uncompressed=${y}`);
  }
  const O = g === void 0 ? C : g, P = p === void 0 ? M : p, L = r.mul(i.b, Ie), K = r.is0(i.a) ? (b) => r.ZERO : (b) => r.mul(i.a, b);
  function ot(b) {
    const u = r.sqr(b), y = r.mul(u, b);
    return r.add(r.add(y, r.mul(b, i.a)), i.b);
  }
  function j(b, u) {
    const y = r.sqr(u), m = ot(b);
    return r.eql(y, m);
  }
  if (!j(i.Gx, i.Gy))
    throw new Error("bad curve params: generator point");
  const D = r.mul(r.pow(i.a, Ie), Wi), st = r.mul(r.sqr(i.b), BigInt(27));
  if (r.is0(r.add(D, st)))
    throw new Error("bad curve params: a or b");
  function et(b, u, y = !1) {
    if (!r.isValid(u) || y && r.is0(u))
      throw new Error(`bad point coordinate ${b}`);
    return typeof u == "object" && u !== null ? r.create(u) : u;
  }
  function nt(b) {
    if (!(b instanceof Q))
      throw new Error("Weierstrass Point expected");
  }
  function ht(b) {
    if (!E || !E.basises)
      throw new Error("no endo");
    return Gi(b, E.basises, o.ORDER);
  }
  function ct(b, u, y, m) {
    if (!o.isValid(m))
      throw new RangeError("invalid scalar: out of range");
    if (E) {
      const { k1neg: _, k1: B, k2neg: v, k2: S } = ht(m), R = new Q(r.mul(y.X, E.beta), y.Y, y.Z);
      b.push(_ ? y.negate() : y, v ? R.negate() : R), u.push(B, S);
    } else
      b.push(y), u.push(m);
  }
  const Et = /* @__PURE__ */ new WeakSet(), A = class A {
    /** Does NOT validate if the point is valid. Use `.assertValidity()`. */
    constructor(u, y, m) {
      l(this, "X");
      l(this, "Y");
      l(this, "Z");
      this.X = et("x", u), this.Y = et("y", y, !0), this.Z = et("z", m), Object.freeze(this);
    }
    static CURVE() {
      return i;
    }
    /** Does NOT validate if the point is valid. Use `.assertValidity()`. */
    static fromAffine(u) {
      const { x: y, y: m } = u || {};
      if (!u || !r.isValid(y) || !r.isValid(m))
        throw new Error("invalid affine point");
      if (u instanceof A)
        throw new Error("projective point not allowed");
      return r.is0(y) && r.is0(m) ? A.ZERO : new A(y, m, r.ONE);
    }
    static fromBytes(u) {
      const y = A.fromAffine(P(Z(u, void 0, "point")));
      return y.assertValidity(), y;
    }
    static fromHex(u) {
      return A.fromBytes(Ue(u));
    }
    get x() {
      return this.toAffine().x;
    }
    get y() {
      return this.toAffine().y;
    }
    /**
     * @param isLazy - true will defer table computation until the first multiplication
     */
    precompute(u = 6, y = !0) {
      return pt.setWindowSize(this, u), y || this.multiply(Ie), this;
    }
    // TODO: return `this`
    /** A point on curve is valid if it conforms to equation. */
    assertValidity() {
      const u = this;
      if (u.is0()) {
        if (f && r.is0(u.X) && r.eql(u.Y, r.ONE) && r.is0(u.Z))
          return;
        throw new Error("bad point: ZERO");
      }
      if (Et.has(u))
        return;
      const { x: y, y: m } = u.toAffine();
      if (!r.isValid(y) || !r.isValid(m))
        throw new Error("bad point: x or y not field elements");
      if (!j(y, m))
        throw new Error("bad point: equation left != right");
      if (!u.isTorsionFree())
        throw new Error("bad point: not in prime-order subgroup");
      Et.add(u);
    }
    hasEvenY() {
      const { y: u } = this.toAffine();
      if (!r.isOdd)
        throw new Error("Field doesn't support isOdd");
      return !r.isOdd(u);
    }
    /** Compare one point to another. */
    equals(u) {
      nt(u);
      const { X: y, Y: m, Z: _ } = this, { X: B, Y: v, Z: S } = u, R = r.eql(r.mul(y, S), r.mul(B, _)), H = r.eql(r.mul(m, S), r.mul(v, _));
      return R && H;
    }
    /** Flips point to one corresponding to (x, -y) in Affine coordinates. */
    negate() {
      return new A(this.X, r.neg(this.Y), this.Z);
    }
    // Renes-Costello-Batina exception-free doubling formula.
    // There is 30% faster Jacobian formula, but it is not complete.
    // https://eprint.iacr.org/2015/1060, algorithm 3
    // Cost: 8M + 3S + 3*a + 2*b3 + 15add.
    double() {
      const { X: u, Y: y, Z: m } = this;
      let _ = r.ZERO, B = r.ZERO, v = r.ZERO, S = r.mul(u, u), R = r.mul(y, y), H = r.mul(m, m), T = r.mul(u, y);
      return T = r.add(T, T), v = r.mul(u, m), v = r.add(v, v), _ = K(v), B = r.mul(L, H), B = r.add(_, B), _ = r.sub(R, B), B = r.add(R, B), B = r.mul(_, B), _ = r.mul(T, _), v = r.mul(L, v), H = K(H), T = r.sub(S, H), T = K(T), T = r.add(T, v), v = r.add(S, S), S = r.add(v, S), S = r.add(S, H), S = r.mul(S, T), B = r.add(B, S), H = r.mul(y, m), H = r.add(H, H), S = r.mul(H, T), _ = r.sub(_, S), v = r.mul(H, R), v = r.add(v, v), v = r.add(v, v), new A(_, B, v);
    }
    // Renes-Costello-Batina exception-free addition formula.
    // There is 30% faster Jacobian formula, but it is not complete.
    // https://eprint.iacr.org/2015/1060, algorithm 1
    // Cost: 12M + 0S + 3*a + 3*b3 + 23add.
    add(u) {
      nt(u);
      const { X: y, Y: m, Z: _ } = this, { X: B, Y: v, Z: S } = u;
      let R = r.ZERO, H = r.ZERO, T = r.ZERO, N = r.mul(y, B), k = r.mul(m, v), q = r.mul(_, S), G = r.add(y, m), F = r.add(B, v);
      G = r.mul(G, F), F = r.add(N, k), G = r.sub(G, F), F = r.add(y, _);
      let W = r.add(B, S);
      return F = r.mul(F, W), W = r.add(N, q), F = r.sub(F, W), W = r.add(m, _), R = r.add(v, S), W = r.mul(W, R), R = r.add(k, q), W = r.sub(W, R), T = K(F), R = r.mul(L, q), T = r.add(R, T), R = r.sub(k, T), T = r.add(k, T), H = r.mul(R, T), k = r.add(N, N), k = r.add(k, N), q = K(q), F = r.mul(L, F), k = r.add(k, q), q = r.sub(N, q), q = K(q), F = r.add(F, q), N = r.mul(k, F), H = r.add(H, N), N = r.mul(W, F), R = r.mul(G, R), R = r.sub(R, N), N = r.mul(G, k), T = r.mul(W, T), T = r.add(T, N), new A(R, H, T);
    }
    subtract(u) {
      return nt(u), this.add(u.negate());
    }
    is0() {
      return this.equals(A.ZERO);
    }
    /**
     * Constant time multiplication.
     * Uses precomputed tables (signed fixed-window wNAF) when available.
     * Uses scalar blinding and avoids endomorphism splitting in the secret-scalar path.
     * @param scalar - by which the point would be multiplied
     * @returns New point
     */
    multiply(u) {
      if (!o.isValidNot0(u))
        throw new RangeError("invalid scalar: out of range");
      const { p: y, f: m } = pt.mulSecret(this, u, s, $t);
      return $t([y, m])[0];
    }
    /**
     * Non-constant-time multiplication. Uses width-4 wNAF with GLV endomorphism splitting
     * when available (two half-width scalars sharing one halved doubling chain).
     * It's faster, but should only be used when you don't care about
     * an exposed secret key e.g. sig verification, which works over *public* keys.
     */
    multiplyUnsafe(u) {
      const y = this, m = u;
      if (!o.isValid(m))
        throw new RangeError("invalid scalar: out of range");
      if (m === dt || y.is0())
        return A.ZERO;
      if (m === At)
        return y;
      if (pt.hasWindowSize(this))
        return pt.mulUnsafe(y, m, $t);
      const _ = [], B = [];
      return ct(_, B, y, m), Ne(A, _, B);
    }
    /**
     * Non-constant-time double-scalar multiplication `a⋅this + b⋅other` (Strauss–Shamir).
     * Both walks share one doubling chain via {@link mulAddUnsafe}, and GLV endomorphism
     * (when available) halves the chain again by splitting each scalar into two half-width
     * parts. Used by ECDSA verification and public-key recovery for `R = u1⋅G + u2⋅P`.
     * Only for public scalars.
     */
    mulAddUnsafe(u, y, m) {
      nt(y);
      const _ = [], B = [];
      return ct(_, B, this, u), ct(_, B, y, m), Ne(A, _, B);
    }
    /**
     * Converts Projective point to affine (x, y) coordinates.
     * (X, Y, Z) ∋ (x=X/Z, y=Y/Z).
     * @param invertedZ - Z^-1 (inverted zero) - optional, precomputation is useful for invertBatch
     */
    toAffine(u) {
      const y = this;
      let m = u;
      if (m != null && !r.isValid(m))
        throw new RangeError('"invertedZ" expected valid field element');
      const { X: _, Y: B, Z: v } = y;
      if (r.eql(v, r.ONE))
        return { x: _, y: B };
      const S = y.is0();
      m == null && (m = S ? r.ONE : r.inv(v));
      const R = r.mul(_, m), H = r.mul(B, m), T = r.mul(v, m);
      if (S)
        return { x: r.ZERO, y: r.ZERO };
      if (!r.eql(T, r.ONE))
        throw new Error("invZ was invalid");
      return { x: R, y: H };
    }
    /**
     * Checks whether Point is free of torsion elements (is in prime subgroup).
     * Always torsion-free for cofactor=1 curves.
     */
    isTorsionFree() {
      return s === At ? !0 : w ? w(A, this) : pt.mulUnsafe(this, c).is0();
    }
    clearCofactor() {
      return s === At ? this : d ? d(A, this) : this.multiplyUnsafe(s);
    }
    isSmallOrder() {
      return s === At ? this.is0() : this.clearCofactor().is0();
    }
    toBytes(u = !0) {
      return It(u, "isCompressed"), this.assertValidity(), O(A, this, u);
    }
    toHex(u = !0) {
      return Gn(this.toBytes(u));
    }
    toString() {
      return `<Point ${this.is0() ? "ZERO" : this.toHex()}>`;
    }
  };
  l(A, "BASE", new A(i.Gx, i.Gy, r.ONE)), l(A, "ZERO", new A(r.ZERO, r.ONE, r.ZERO)), l(A, "Fp", r), l(A, "Fn", o);
  let Q = A;
  const $t = (b) => Fi(Q, b), pt = new ji(Q, h);
  return pt.bits >= 6 && Q.BASE.precompute(6), Object.freeze(Q.prototype), Object.freeze(Q), Q;
}
function wr(e) {
  return Uint8Array.of(e ? 2 : 3);
}
function gr(e, t) {
  return {
    secretKey: t.BYTES,
    publicKey: 1 + e.BYTES,
    publicKeyUncompressed: 1 + 2 * e.BYTES,
    publicKeyHasPrefix: !0,
    // Raw compact `(r || s)` signature width; DER and recovered signatures use
    // different lengths outside this helper.
    signature: 2 * t.BYTES
  };
}
function Ji(e, t = {}) {
  ne(e);
  const { Fn: n } = e, r = t.randomBytes === void 0 ? je : t.randomBytes, o = Object.assign(gr(e.Fp, n), {
    seed: Math.max(Je(n.ORDER), 16)
  });
  function i(g) {
    try {
      const h = n.fromBytes(g);
      return n.isValidNot0(h);
    } catch {
      return !1;
    }
  }
  function s(g, h) {
    const { publicKey: E, publicKeyUncompressed: x } = o;
    try {
      const I = g.length;
      return h === !0 && I !== E || h === !1 && I !== x ? !1 : !e.fromBytes(g).is0();
    } catch {
      return !1;
    }
  }
  function c(g) {
    return g = g === void 0 ? r(o.seed) : g, dr(Z(g, o.seed, "seed"), n.ORDER);
  }
  function a(g, h = !0) {
    return e.BASE.multiply(n.fromBytes(g)).toBytes(h);
  }
  function f(g) {
    const { secretKey: h, publicKey: E, publicKeyUncompressed: x } = o, I = n._lengths;
    if (!ye(g))
      return;
    const C = Z(g, void 0, "key").length, M = C === E || C === x, O = C === h || !!(I != null && I.includes(C));
    if (!(M && O))
      return M;
  }
  function d(g, h, E = !0) {
    if (f(g) === !0)
      throw new Error("first arg must be private key");
    if (f(h) === !1)
      throw new Error("second arg must be public key");
    const x = n.fromBytes(g), I = e.fromBytes(h);
    if (I.is0())
      throw new Error("invalid public key: point at infinity");
    return I.multiply(x).toBytes(E);
  }
  const w = {
    isValidSecretKey: i,
    isValidPublicKey: s,
    randomSecretKey: c
  }, p = Zi(c, a);
  return Object.freeze(w), Object.freeze(o), Object.freeze({ getPublicKey: a, getSharedSecret: d, keygen: p, Point: e, utils: w, lengths: o });
}
function Qi(e, t, n = {}) {
  ne(e);
  const r = t;
  Kn(r), ee(n, {}, {
    hmac: "function",
    lowS: "boolean",
    randomBytes: "function",
    bits2int: "function",
    bits2int_modN: "function"
  });
  const o = Object.assign({}, n), i = o.randomBytes === void 0 ? je : o.randomBytes, s = o.hmac === void 0 ? (A, b) => Le(r, A, b) : o.hmac, { Fp: c, Fn: a } = e, { ORDER: f, BITS: d } = a, w = Je(f), p = ur(i, w), { keygen: g, getPublicKey: h, getSharedSecret: E, utils: x, lengths: I } = Ji(e, o), C = {
    prehash: !0,
    lowS: typeof o.lowS == "boolean" ? o.lowS : !0,
    format: "compact",
    extraEntropy: !1
  }, M = f * pr + At < c.ORDER;
  function O(A) {
    const b = f >> At;
    return A > b;
  }
  function P(A, b) {
    if (!a.isValidNot0(b))
      throw new Error(`invalid signature ${A}: out of range 1..Point.Fn.ORDER`);
    return b;
  }
  function L() {
    if (!c.isOdd)
      throw new Error("Field doesn't support isOdd");
  }
  function K(A, b, u) {
    return L(), (A === u ? 0 : 2) | Number(c.isOdd(b));
  }
  function ot() {
    if (M)
      throw new Error('"recovered" sig type is not supported for cofactor >2 curves');
  }
  function j(A, b) {
    Fe(b);
    const u = I.signature, y = b === "compact" ? u : b === "recovered" ? u + 1 : void 0;
    return Z(A, y);
  }
  class D {
    constructor(b, u, y) {
      l(this, "r");
      l(this, "s");
      l(this, "recovery");
      if (this.r = P("r", b), this.s = P("s", u), y != null) {
        if (ot(), ![0, 1, 2, 3].includes(y))
          throw new Error("invalid recovery id");
        this.recovery = y;
      }
      Object.freeze(this);
    }
    static fromBytes(b, u = C.format) {
      j(b, u);
      let y;
      if (u === "der") {
        if (b.length > 2 * a.BYTES + 16)
          throw new _e.Err("invalid signature: DER signature too long");
        const { r: v, s: S } = _e.toSig(Z(b), a.BYTES + 1);
        return new D(v, S);
      }
      u === "recovered" && (y = b[0], u = "compact", b = b.subarray(1));
      const m = I.signature / 2, _ = b.subarray(0, m), B = b.subarray(m, m * 2);
      return new D(a.fromBytes(_), a.fromBytes(B), y);
    }
    static fromHex(b, u) {
      return this.fromBytes(Ue(b), u);
    }
    assertRecovery() {
      const { recovery: b } = this;
      if (b == null)
        throw new Error("invalid recovery id: must be present");
      return b;
    }
    addRecoveryBit(b) {
      return new D(this.r, this.s, b);
    }
    // Unlike the top-level helper below, this method expects a digest that has
    // already been hashed to the curve's message representative.
    recoverPublicKey(b) {
      const { r: u, s: y } = this, m = this.assertRecovery(), _ = m === 2 || m === 3 ? u + f : u;
      if (!c.isValid(_))
        throw new Error("invalid recovery id: sig.r+curve.n != R.x");
      const B = c.toBytes(_), v = e.fromBytes(mt(wr((m & 1) === 0), B)), S = a.inv(_), R = et(Z(b, void 0, "msgHash")), H = a.create(-R * S), T = a.create(y * S), N = e.BASE.mulAddUnsafe(H, v, T);
      if (N.is0())
        throw new Error("invalid recovery: point at infinify");
      return N.assertValidity(), N;
    }
    // Signatures should be low-s, to prevent malleability.
    hasHighS() {
      return O(this.s);
    }
    toBytes(b = C.format) {
      if (Fe(b), b === "der")
        return Ue(_e.hexFromSig(this));
      const { r: u, s: y } = this, m = a.toBytes(u), _ = a.toBytes(y);
      return b === "recovered" ? (ot(), mt(Uint8Array.of(this.assertRecovery()), m, _)) : mt(m, _);
    }
    toHex(b) {
      return Gn(this.toBytes(b));
    }
  }
  Object.freeze(D.prototype), Object.freeze(D);
  const st = o.bits2int === void 0 ? function(b) {
    if (b.length > 8192)
      throw new Error("input is too large");
    const u = kt(b), y = b.length * 8 - d;
    return y > 0 ? u >> BigInt(y) : u;
  } : o.bits2int, et = o.bits2int_modN === void 0 ? function(b) {
    return a.create(st(b));
  } : o.bits2int_modN, nt = Xe(d);
  function ht(A) {
    return tr("num < 2^" + d, A, dt, nt), a.toBytes(A);
  }
  function ct(A, b) {
    return Z(A, void 0, "message"), b ? Z(r(A), void 0, "prehashed message") : A;
  }
  function Et(A, b, u) {
    const { lowS: y, prehash: m, extraEntropy: _ } = Be(u, C);
    A = ct(A, m);
    const B = et(A), v = a.fromBytes(b);
    if (!a.isValidNot0(v))
      throw new Error("invalid private key");
    const S = [ht(v), ht(B)];
    if (_ != null && _ !== !1) {
      const N = _ === !0 ? i(I.secretKey) : _;
      S.push(Z(N, void 0, "extraEntropy"));
    }
    const R = mt(...S), H = B;
    function T(N) {
      const k = st(N);
      if (!a.isValidNot0(k))
        return;
      const q = e.BASE.multiply(k).toAffine(), G = a.create(q.x);
      if (G === dt)
        return;
      let F;
      if (p !== void 0) {
        const Mt = kt(dr(p(w), f)), kr = a.inv(a.mul(Mt, k)), $r = a.mul(Mt, H), Mr = a.mul(Mt, v);
        F = a.create(kr * a.create($r + Mr * G));
      } else {
        const Mt = Si(k, f);
        F = a.create(Mt * a.create(H + G * v));
      }
      if (F === dt)
        return;
      let W = K(q.x, q.y, G), fn = F;
      return y && O(F) && (fn = a.neg(F), W ^= 1), new D(G, fn, M ? void 0 : W);
    }
    return { seed: R, k2sig: T };
  }
  function Q(A, b, u = {}) {
    const { seed: y, k2sig: m } = Et(A, b, u);
    return Ai(r.outputLen, a.BYTES, s)(y, m).toBytes(u.format);
  }
  function $t(A, b, u, y = {}) {
    const { lowS: m, prehash: _, format: B } = Be(y, C);
    if (u = Z(u, void 0, "publicKey"), b = ct(b, _), !ye(A)) {
      const v = A instanceof D ? ", use sig.toBytes()" : "";
      throw new Error("verify expects Uint8Array signature" + v);
    }
    j(A, B);
    try {
      const v = D.fromBytes(A, B), S = e.fromBytes(u);
      if (S.is0() || m && v.hasHighS())
        return !1;
      const { r: R, s: H } = v, T = et(b), N = a.inv(H), k = a.create(T * N), q = a.create(R * N), G = e.BASE.mulAddUnsafe(k, S, q);
      if (G.is0())
        return !1;
      const F = G.toAffine();
      return !(a.create(F.x) !== R || B === "recovered" && v.recovery !== K(F.x, F.y, R));
    } catch {
      return !1;
    }
  }
  function pt(A, b, u = {}) {
    const { prehash: y } = Be(u, C);
    return b = ct(b, y), D.fromBytes(A, "recovered").recoverPublicKey(b).toBytes();
  }
  return Object.freeze({
    keygen: g,
    getPublicKey: h,
    getSharedSecret: E,
    utils: x,
    lengths: I,
    Point: e,
    sign: Q,
    verify: $t,
    recoverPublicKey: pt,
    Signature: D,
    hash: r
  });
}
const tn = {
  p: BigInt("0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2f"),
  n: BigInt("0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141"),
  h: BigInt(1),
  a: BigInt(0),
  b: BigInt(7),
  Gx: BigInt("0x79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798"),
  Gy: BigInt("0x483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8")
}, to = {
  beta: BigInt("0x7ae96a2b657c07106e64479eac3434e99cf0497512f58995c1396c28719501ee"),
  basises: [
    [BigInt("0x3086d221a7d46bcde86c90e49284eb15"), -BigInt("0xe4437ed6010e88286f547fa90abfe4c3")],
    [BigInt("0x114ca50f7a8e2f3f657c1108d9d44cfd8"), BigInt("0x3086d221a7d46bcde86c90e49284eb15")]
  ]
}, On = /* @__PURE__ */ BigInt(2);
function eo(e) {
  const t = tn.p, n = BigInt(3), r = BigInt(6), o = BigInt(11), i = BigInt(22), s = BigInt(23), c = BigInt(44), a = BigInt(88), f = e * e * e % t, d = f * f * e % t, w = tt(d, n, t) * d % t, p = tt(w, n, t) * d % t, g = tt(p, On, t) * f % t, h = tt(g, o, t) * g % t, E = tt(h, i, t) * h % t, x = tt(E, c, t) * E % t, I = tt(x, a, t) * x % t, C = tt(I, c, t) * E % t, M = tt(C, n, t) * d % t, O = tt(M, s, t) * h % t, P = tt(O, r, t) * f % t, L = tt(P, On, t);
  if (!De.eql(De.sqr(L), e))
    throw new Error("Cannot find square root");
  return L;
}
const De = /* @__PURE__ */ me(tn.p, { sqrt: eo }), no = /* @__PURE__ */ Vi(tn, {
  Fp: De,
  endo: to
}), Ut = /* @__PURE__ */ Qi(no, qe), ro = /* @__PURE__ */ Uint8Array.from([
  7,
  4,
  13,
  1,
  10,
  6,
  15,
  3,
  12,
  0,
  9,
  5,
  2,
  14,
  11,
  8
]), br = Uint8Array.from(new Array(16).fill(0).map((e, t) => t)), io = br.map((e) => (9 * e + 5) % 16), yr = /* @__PURE__ */ (() => {
  const n = [[br], [io]];
  for (let r = 0; r < 4; r++)
    for (let o of n)
      o.push(o[r].map((i) => ro[i]));
  return n;
})(), mr = yr[0], xr = yr[1], Er = /* @__PURE__ */ [
  [11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8],
  [12, 13, 11, 15, 6, 9, 9, 7, 12, 15, 11, 13, 7, 8, 7, 7],
  [13, 15, 14, 11, 7, 7, 6, 8, 13, 14, 13, 12, 5, 5, 6, 9],
  [14, 11, 12, 14, 8, 6, 5, 5, 15, 12, 15, 14, 9, 9, 8, 6],
  [15, 12, 13, 13, 9, 5, 8, 6, 14, 11, 12, 11, 8, 6, 5, 5]
].map((e) => Uint8Array.from(e)), oo = /* @__PURE__ */ mr.map((e, t) => e.map((n) => Er[t][n])), so = /* @__PURE__ */ xr.map((e, t) => e.map((n) => Er[t][n])), co = /* @__PURE__ */ Uint32Array.from([
  0,
  1518500249,
  1859775393,
  2400959708,
  2840853838
]), ao = /* @__PURE__ */ Uint32Array.from([
  1352829926,
  1548603684,
  1836072691,
  2053994217,
  0
]);
function Tn(e, t, n, r) {
  return e === 0 ? t ^ n ^ r : e === 1 ? t & n | ~t & r : e === 2 ? (t | ~n) ^ r : e === 3 ? t & r | n & ~r : t ^ (n | ~r);
}
const ae = /* @__PURE__ */ new Uint32Array(16);
class fo extends Ke {
  constructor() {
    super(64, 20, 8, !0);
    l(this, "h0", 1732584193);
    l(this, "h1", -271733879);
    l(this, "h2", -1732584194);
    l(this, "h3", 271733878);
    l(this, "h4", -1009589776);
  }
  get() {
    const { h0: n, h1: r, h2: o, h3: i, h4: s } = this;
    return [n, r, o, i, s];
  }
  set(n, r, o, i, s) {
    this.h0 = n | 0, this.h1 = r | 0, this.h2 = o | 0, this.h3 = i | 0, this.h4 = s | 0;
  }
  _cloneInto(n) {
    return (n || (n = new this.constructor())).set(...this.get()), this._cloneIntoMeta(n);
  }
  process(n, r) {
    for (let h = 0; h < 16; h++, r += 4)
      ae[h] = n.getUint32(r, !0);
    let o = this.h0 | 0, i = o, s = this.h1 | 0, c = s, a = this.h2 | 0, f = a, d = this.h3 | 0, w = d, p = this.h4 | 0, g = p;
    for (let h = 0; h < 5; h++) {
      const E = 4 - h, x = co[h], I = ao[h], C = mr[h], M = xr[h], O = oo[h], P = so[h];
      for (let L = 0; L < 16; L++) {
        const K = se(o + Tn(h, s, a, d) + ae[C[L]] + x, O[L]) + p | 0;
        o = p, p = d, d = se(a, 10) | 0, a = s, s = K;
      }
      for (let L = 0; L < 16; L++) {
        const K = se(i + Tn(E, c, f, w) + ae[M[L]] + I, P[L]) + g | 0;
        i = g, g = w, w = se(f, 10) | 0, f = c, c = K;
      }
    }
    this.set(this.h1 + a + w | 0, this.h2 + d + g | 0, this.h3 + p + i | 0, this.h4 + o + c | 0, this.h0 + s + f | 0);
  }
  roundClean() {
    lt(ae);
  }
  destroy() {
    this.destroyed = !0, lt(this.buffer), this.set(0, 0, 0, 0, 0);
  }
}
const uo = /* @__PURE__ */ ge(() => new fo());
const lo = (e) => Object.freeze(e());
function ho(e) {
  return e instanceof Uint8Array || ArrayBuffer.isView(e) && e.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in e && e.BYTES_PER_ELEMENT === 1;
}
function Jt(e) {
  if (!ho(e))
    throw new TypeError("Uint8Array expected");
}
function vr(e) {
  if (typeof e != "function")
    throw new TypeError("function expected");
  return !0;
}
function Ar(e, t) {
  if (typeof t != "string")
    throw new TypeError(`${e}: string expected`);
  return !0;
}
function po(e, t = "number") {
  if (typeof e != "number")
    throw new TypeError(`${t}: expected number, got ${typeof e}`);
  if (!Number.isSafeInteger(e))
    throw new RangeError(`${t}: expected safe integer, got ${e}`);
}
function wo(...e) {
  const t = (i) => i, n = (i, s) => (c) => i(s(c)), r = e.map((i) => i.encode).reduceRight(n, t), o = e.map((i) => i.decode).reduce(n, t);
  return { encode: r, decode: o };
}
const Cn = /* @__PURE__ */ (() => {
  try {
    const e = new TextDecoder();
    return e.decode(Uint8Array.of(65, 48, 43, 127)) === "A0+" ? e : void 0;
  } catch {
    return;
  }
})(), Re = 8192;
function go(e) {
  const t = e.length;
  if (Cn !== void 0 && t >= 12)
    return Cn.decode(e);
  if (t <= Re)
    return String.fromCharCode.apply(null, e);
  let n = "";
  for (let r = 0; r < t; r += Re)
    n += String.fromCharCode.apply(null, e.subarray(r, r + Re));
  return n;
}
function bo(e, t) {
  const n = e.length;
  if (n > 128)
    throw new Error("alphabet: max 128 letters");
  const r = new Uint8Array(n), o = new Int8Array(128).fill(-1);
  for (let i = 0; i < n; i++) {
    const s = e.charCodeAt(i);
    if (e.codePointAt(i) !== s || s > 127)
      throw new Error("alphabet: single-char ASCII letters only");
    r[i] = s, o[s] = i;
  }
  if (t !== void 0)
    for (const i of Object.keys(t)) {
      const s = i.charCodeAt(0), c = o[t[i].charCodeAt(0)];
      if (i.length !== 1 || s > 127 || c === void 0 || c === -1)
        throw new Error(`alphabet: invalid alias ${i}`);
      o[s] = c;
    }
  return {
    encode: (i) => {
      const s = new Uint8Array(i.length);
      for (let c = 0; c < i.length; c++) {
        const a = i[c], f = r[a];
        if (f === void 0)
          throw new Error(`alphabet.encode: invalid digit ${a}`);
        s[c] = f;
      }
      return go(s);
    },
    decode: (i) => {
      Ar("decode", i);
      const s = i.length, c = new Uint8Array(s);
      for (let a = 0; a < s; a++) {
        const f = i.charCodeAt(a), d = f < 128 ? o[f] : -1;
        if (d === -1)
          throw new Error(`Unknown letter "${i[a]}". Allowed: ${e}`);
        c[a] = d;
      }
      return c;
    }
  };
}
function yo(e, t) {
  if (po(e), e <= 0)
    throw new RangeError(`checksum length must be positive: ${e}`);
  vr(t);
  const n = t;
  return {
    encode(r) {
      Jt(r);
      const o = n(r).slice(0, e), i = new Uint8Array(r.length + e);
      return i.set(r), i.set(o, r.length), i;
    },
    decode(r) {
      Jt(r);
      const o = r.slice(0, -e), i = r.slice(-e), s = n(o).slice(0, e);
      for (let c = 0; c < e; c++)
        if (s[c] !== i[c])
          throw new Error("Invalid checksum");
      return o;
    }
  };
}
const mo = 656356768, Hn = 65536, xo = 2048, Eo = 4096, vo = (e, t) => ({
  encode: (n) => {
    Jt(n);
    const r = n.length;
    if (r === 0)
      return new Uint8Array(0);
    if (r >= Hn)
      throw new Error("invalid length");
    let o = 0;
    for (; o < r - 1 && n[o] === 0; )
      o++;
    const i = Math.ceil(r / 2), s = new Uint16Array(i), c = r & 1;
    c && (s[0] = n[0]);
    for (let h = c, E = c; h < r; h += 2, E++)
      s[E] = n[h] << 8 | n[h + 1];
    const a = [];
    let f = 0;
    for (; f < i; ) {
      let h = 0;
      for (let E = f; E < i; E++) {
        const x = h * 65536 + s[E], I = Math.floor(x / t);
        h = x - I * t, s[E] = I, I === 0 && E === f && f++;
      }
      a.push(h);
    }
    const d = a.length - 1;
    let w = d * 5;
    for (let h = a[d]; w++, !(h < e); h = Math.floor(h / e))
      ;
    const p = new Uint8Array(o + w);
    let g = p.length - 1;
    for (let h = 0; h < d; h++) {
      let E = a[h];
      for (let x = 0; x < 5; x++)
        p[g--] = E % e, E = Math.floor(E / e);
    }
    for (let h = a[d]; g >= o; h = Math.floor(h / e))
      p[g--] = h % e;
    return p;
  },
  decode: (n) => {
    Jt(n);
    const r = n.length;
    if (r === 0)
      return new Uint8Array(0);
    if (r >= Hn)
      throw new Error("invalid length");
    let o = 0;
    for (; o < r - 1 && n[o] === 0; )
      o++;
    const i = new Uint16Array(Math.ceil(r * 6 / 16) + 1);
    let s = 0, c = 0, a = r % 5 || 5;
    for (; c < r; ) {
      let p = 0, g = 1;
      for (const E = c + a; c < E; c++) {
        const x = n[c];
        if (x >= e)
          throw new Error(`invalid integer: ${x}`);
        p = p * e + x, g *= e;
      }
      a = 5;
      let h = p;
      for (let E = 0; E < s; E++) {
        const x = i[E] * g + h;
        h = Math.floor(x / 65536), i[E] = x - h * 65536;
      }
      for (; h > 0; h = Math.floor(h / 65536))
        i[s++] = h % 65536;
    }
    const f = s === 0 ? 1 : s * 2 - (i[s - 1] < 256 ? 1 : 0), d = new Uint8Array(o + f);
    let w = d.length - 1;
    for (let p = 0; p < s; p++) {
      const g = i[p];
      d[w--] = g & 255, w >= o && (d[w--] = g >> 8);
    }
    return d;
  }
}), Ao = (e, t) => {
  const n = bo(t);
  return {
    encode(r) {
      if (Jt(r), r.length > xo)
        throw new Error("invalid length");
      return n.encode(e.encode(r));
    },
    decode(r) {
      if (Ar("baseN.decode", r), r.length > Eo)
        throw new Error("invalid length");
      return e.decode(n.decode(r));
    }
  };
}, _o = /* @__PURE__ */ vo(58, mo), Bo = (e) => Ao(_o, e), Io = /* @__PURE__ */ lo(() => Bo("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz")), Ro = (e) => {
  vr(e);
  const t = e;
  return wo(yo(4, (n) => t(t(n))), Io);
};
const Zt = Ut.Point, Tt = Zt.Fn, Se = /* @__PURE__ */ Ro(qe), So = Uint8Array.from("Bitcoin seed".split(""), (e) => e.charCodeAt(0)), Oe = { private: 76066276, public: 76067358 }, fe = 2147483648, Te = 255, Oo = (e) => uo(qe(e)), To = (e) => Nt(e).getUint32(0, !1), yt = (e, t = "number") => {
  if (typeof e != "number")
    throw new TypeError(`"${t}" expected number, got type=${typeof e}`);
  if (!Number.isSafeInteger(e) || e < 0 || e > 2 ** 32 - 1)
    throw new RangeError(`"${t}" expected integer in range 0..2**32-1, got ${e}`);
  const n = new Uint8Array(4);
  return Nt(n).setUint32(0, e, !1), n;
}, Ce = (e, t = "versions") => {
  if (!(typeof e == "object" && e !== null))
    throw new Error("versions must be an object");
  return yt(e.private, `${t}.private`), yt(e.public, `${t}.public`), e;
};
class vt {
  constructor(t) {
    l(this, "versions");
    l(this, "depth", 0);
    l(this, "index", 0);
    l(this, "parentFingerprint", 0);
    l(this, "_chainCode", null);
    l(this, "_privateKey");
    l(this, "_publicKey");
    l(this, "_pubHash");
    var i, s, c;
    if (!t || typeof t != "object")
      throw new Error("HDKey.constructor must not be called directly");
    const n = (i = t.depth) != null ? i : 0, r = (s = t.index) != null ? s : 0, o = (c = t.parentFingerprint) != null ? c : 0;
    if (!Number.isSafeInteger(n) || n < 0 || n > Te)
      throw new RangeError("HDKey: depth must be an integer in range 0..255");
    if (yt(r, "index"), yt(o, "parentFingerprint"), n === 0 && (r !== 0 || o !== 0))
      throw new Error("HDKey: zero depth with non-zero index/parent fingerprint");
    if (this.versions = t.versions ? Ce(t.versions) : Oe, this.depth = n, t.chainCode && Y(t.chainCode, 32), this._chainCode = t.chainCode ? Uint8Array.from(t.chainCode) : null, this.index = r, this.parentFingerprint = o, t.publicKey && t.privateKey)
      throw new Error("HDKey: publicKey and privateKey at same time.");
    if (t.privateKey) {
      if (!Ut.utils.isValidSecretKey(t.privateKey))
        throw new Error("Invalid private key");
      this._privateKey = Uint8Array.from(t.privateKey), this._publicKey = Ut.getPublicKey(this._privateKey, !0);
    } else if (t.publicKey)
      this._publicKey = Zt.fromBytes(t.publicKey).toBytes(!0);
    else
      throw new Error("HDKey: no public or private key provided");
    this._pubHash = Oo(this._publicKey);
  }
  get fingerprint() {
    if (!this._pubHash)
      throw new Error("No publicKey set!");
    return To(this._pubHash);
  }
  get identifier() {
    return this._pubHash ? Uint8Array.from(this._pubHash) : void 0;
  }
  get pubKeyHash() {
    return this._pubHash ? Uint8Array.from(this._pubHash) : void 0;
  }
  get privateKey() {
    return this._privateKey ? Uint8Array.from(this._privateKey) : null;
  }
  get publicKey() {
    return this._publicKey ? Uint8Array.from(this._publicKey) : null;
  }
  get chainCode() {
    return this._chainCode ? Uint8Array.from(this._chainCode) : null;
  }
  get privateExtendedKey() {
    const t = this._privateKey;
    if (!t)
      throw new Error("No private key");
    return Se.encode(this.serialize(this.versions.private, Yt(Uint8Array.of(0), t)));
  }
  get publicExtendedKey() {
    if (!this._publicKey)
      throw new Error("No public key");
    return Se.encode(this.serialize(this.versions.public, this._publicKey));
  }
  static fromMasterSeed(t, n = Oe) {
    if (Y(t), n = Ce(n), 8 * t.length < 128 || 8 * t.length > 512)
      throw new RangeError("HDKey: seed length must be between 128 and 512 bits; 256 bits is advised, got " + t.length);
    const r = Le(bn, So, t), o = r.slice(0, 32), i = r.slice(32);
    return new vt({ versions: n, chainCode: i, privateKey: o });
  }
  static fromExtendedKey(t, n = Oe) {
    n = Ce(n);
    const r = Se.decode(t);
    if (r.length !== 78)
      throw new Error(`HDKey: invalid extended key length: expected 78 bytes, got ${r.length}`);
    const o = Nt(r), i = o.getUint32(0, !1), s = {
      versions: n,
      depth: r[4],
      parentFingerprint: o.getUint32(5, !1),
      index: o.getUint32(9, !1),
      chainCode: r.slice(13, 45)
    }, c = r.slice(45), a = c[0] === 0;
    if (i !== n[a ? "private" : "public"])
      throw new Error("Version mismatch");
    return a ? new vt({ ...s, privateKey: c.slice(1) }) : new vt({ ...s, publicKey: c });
  }
  static fromJSON(t) {
    return vt.fromExtendedKey("xpriv" in t ? t.xpriv : t.xpub);
  }
  derive(t) {
    if (!/^[mM]'?/.test(t))
      throw new Error('Path must start with "m" or "M"');
    if (/^[mM]'?$/.test(t))
      return this;
    const n = t.replace(/^[mM]'?\//, "").split("/");
    if (n.length > Te - this.depth)
      throw new Error("HDKey: path exceeds the serializable depth 255");
    let r = this;
    for (const o of n) {
      const i = /^(\d+)('?)$/.exec(o), s = i && i[1];
      if (!i || i.length !== 3 || typeof s != "string")
        throw new Error("invalid child index: " + o);
      let c = +s;
      if (!Number.isSafeInteger(c) || c >= fe)
        throw new Error("Invalid index");
      i[2] === "'" && (c += fe), r = r.deriveChild(c);
    }
    return r;
  }
  deriveChild(t) {
    return this._deriveChild(t);
  }
  /** Test-only implementation seam. Production callers must use deriveChild(). */
  _deriveChild(t, n) {
    if (!this._publicKey || !this._chainCode)
      throw new Error("No publicKey or chainCode set");
    let r = yt(t, "index");
    if (t >= fe) {
      const d = this._privateKey;
      if (!d)
        throw new Error("Could not derive hardened child key");
      r = Yt(Uint8Array.of(0), d, r);
    } else
      r = Yt(this._publicKey, r);
    const o = n || Le(bn, this._chainCode, r);
    Y(o, 64);
    const i = o.slice(0, 32), s = o.slice(32), c = {
      versions: this.versions,
      chainCode: s,
      depth: this.depth + 1,
      parentFingerprint: this.fingerprint,
      index: t
    };
    if (c.depth > Te)
      throw new Error("HDKey: depth exceeds the serializable value 255");
    const a = () => {
      const d = this._privateKey ? 4294967295 : fe - 1;
      if (t >= d)
        throw new Error(`HDKey: cannot retry child derivation at index ${t}`);
      return this.deriveChild(t + 1);
    }, f = Tt.fromBytes(i, !0);
    if (!Tt.isValid(f))
      return a();
    if (this._privateKey) {
      const d = Tt.create(Tt.fromBytes(this._privateKey) + f);
      if (!Tt.isValidNot0(d))
        return a();
      c.privateKey = Tt.toBytes(d);
    } else {
      const d = Zt.fromBytes(this._publicKey), w = f === 0n ? d : d.add(Zt.BASE.multiply(f));
      if (w.equals(Zt.ZERO))
        return a();
      c.publicKey = w.toBytes(!0);
    }
    return new vt(c);
  }
  sign(t) {
    if (!this._privateKey)
      throw new Error("No privateKey set!");
    return Y(t, 32), Ut.sign(t, this._privateKey, { prehash: !1 });
  }
  verify(t, n) {
    if (Y(t, 32), Y(n, 64), !this._publicKey)
      throw new Error("No publicKey set!");
    return Ut.verify(n, t, this._publicKey, { prehash: !1 });
  }
  wipePrivateData() {
    return this._privateKey && (this._privateKey.fill(0), this._privateKey = void 0), this;
  }
  // TODO(v3): Make automatic JSON serialization public-only so JSON.stringify cannot expose xpriv.
  toJSON() {
    return this.toPrivateJSON();
  }
  /**
   * Explicitly exports private key material. Treat the returned value as a secret.
   */
  toPrivateJSON() {
    return {
      xpriv: this.privateExtendedKey,
      xpub: this.publicExtendedKey
    };
  }
  serialize(t, n) {
    if (!this._chainCode)
      throw new Error("No chainCode set");
    return Y(n, 33), Yt(yt(t, "version"), new Uint8Array([this.depth]), yt(this.parentFingerprint, "parentFingerprint"), yt(this.index, "index"), this._chainCode, n);
  }
}
const Co = BigInt(0), Pt = BigInt(1), Ho = BigInt(2), Lo = BigInt(7), Uo = BigInt(256), No = BigInt(113), _r = [], Br = [], Ir = [];
for (let e = 0, t = Pt, n = 1, r = 0; e < 24; e++) {
  [n, r] = [r, (2 * n + 3 * r) % 5], _r.push(2 * (5 * r + n)), Br.push((e + 1) * (e + 2) / 2 % 64);
  let o = Co;
  for (let i = 0; i < 7; i++)
    t = (t << Pt ^ (t >> Lo) * No) % Uo, t & Ho && (o ^= Pt << (Pt << BigInt(i)) - Pt);
  Ir.push(o);
}
const Rr = Pn(Ir, !0), Fo = Rr[0], Do = Rr[1], ko = (e, t, n) => e << n | t >>> 32 - n, $o = (e, t, n) => t << n | e >>> 32 - n, Mo = (e, t, n) => t << n - 32 | e >>> 64 - n, Po = (e, t, n) => e << n - 32 | t >>> 64 - n, Ln = (e, t, n) => n > 32 ? Mo(e, t, n) : ko(e, t, n), Un = (e, t, n) => n > 32 ? Po(e, t, n) : $o(e, t, n), Ct = new Uint32Array(10);
function Ko(e, t = 24) {
  if (!(e instanceof Uint32Array))
    throw new TypeError('"s" expected Uint32Array(50), got type=' + typeof e);
  if (e.length !== 50)
    throw new RangeError('"s" expected Uint32Array(50), got length=' + e.length);
  if (V(t, "rounds"), t < 1 || t > 24)
    throw new Error('"rounds" expected integer 1..24');
  for (let n = 24 - t; n < 24; n++) {
    for (let i = 0; i < 10; i++)
      Ct[i] = e[i] ^ e[i + 10] ^ e[i + 20] ^ e[i + 30] ^ e[i + 40];
    for (let i = 0; i < 10; i += 2) {
      const s = (i + 8) % 10, c = (i + 2) % 10, a = Ct[c], f = Ct[c + 1], d = Ln(a, f, 1) ^ Ct[s], w = Un(a, f, 1) ^ Ct[s + 1];
      for (let p = 0; p < 50; p += 10)
        e[i + p] ^= d, e[i + p + 1] ^= w;
    }
    let r = e[2], o = e[3];
    for (let i = 0; i < 24; i++) {
      const s = Br[i], c = Ln(r, o, s), a = Un(r, o, s), f = _r[i];
      r = e[f], o = e[f + 1], e[f] = c, e[f + 1] = a;
    }
    for (let i = 0; i < 50; i += 10) {
      const s = e[i], c = e[i + 1], a = e[i + 2], f = e[i + 3];
      e[i] ^= ~e[i + 2] & e[i + 4], e[i + 1] ^= ~e[i + 3] & e[i + 5], e[i + 2] ^= ~e[i + 4] & e[i + 6], e[i + 3] ^= ~e[i + 5] & e[i + 7], e[i + 4] ^= ~e[i + 6] & e[i + 8], e[i + 5] ^= ~e[i + 7] & e[i + 9], e[i + 6] ^= ~e[i + 8] & s, e[i + 7] ^= ~e[i + 9] & c, e[i + 8] ^= ~s & a, e[i + 9] ^= ~c & f;
    }
    e[0] ^= Fo[n], e[1] ^= Do[n];
  }
  lt(Ct);
}
class en {
  // NOTE: we accept arguments in bytes instead of bits here.
  constructor(t, n, r, o = !1, i = 24) {
    l(this, "state");
    l(this, "pos", 0);
    l(this, "posOut", 0);
    l(this, "finished", !1);
    l(this, "state32");
    l(this, "destroyed", !1);
    l(this, "blockLen");
    l(this, "suffix");
    l(this, "outputLen");
    l(this, "canXOF");
    l(this, "enableXOF", !1);
    l(this, "rounds");
    if (V(t, "blockLen"), V(n, "suffix"), V(i, "rounds"), Qr(o, "enableXOF"), this.blockLen = t, this.suffix = n, this.outputLen = r, this.enableXOF = o, this.canXOF = o, this.rounds = i, V(r, "outputLen"), !(0 < t && t < 200))
      throw new Error('"blockLen" must be 1..199');
    this.state = new Uint8Array(200), this.state32 = pn(this.state);
  }
  clone() {
    return this._cloneInto();
  }
  keccak() {
    wn(this.state32), Ko(this.state32, this.rounds), wn(this.state32), this.posOut = 0, this.pos = 0;
  }
  update(t) {
    Dt(this), Y(t);
    const { blockLen: n, state: r, state32: o } = this, i = t.length, s = n % 4 === 0 && t.byteOffset % 4 === 0, c = n / 4, a = s && i >= n ? pn(t) : void 0;
    for (let f = 0; f < i; ) {
      if (a !== void 0 && this.pos === 0 && f % 4 === 0 && i - f >= n) {
        for (let w = 0, p = f / 4; w < c; w++)
          o[w] ^= a[p + w];
        f += n, this.pos = n, this.keccak();
        continue;
      }
      const d = Math.min(n - this.pos, i - f);
      for (let w = 0; w < d; w++)
        r[this.pos++] ^= t[f++];
      this.pos === n && this.keccak();
    }
    return this;
  }
  finish() {
    if (this.finished)
      return;
    this.finished = !0;
    const { state: t, suffix: n, pos: r, blockLen: o } = this;
    t[r] ^= n, (n & 128) !== 0 && r === o - 1 && this.keccak(), t[o - 1] ^= 128, this.keccak();
  }
  writeInto(t) {
    Dt(this, !1), Y(t), this.finish();
    const n = this.state, { blockLen: r } = this;
    for (let o = 0, i = t.length; o < i; ) {
      this.posOut >= r && this.keccak();
      const s = Math.min(r - this.posOut, i - o);
      t.set(n.subarray(this.posOut, this.posOut + s), o), this.posOut += s, o += s;
    }
    return t;
  }
  xofInto(t) {
    if (!this.enableXOF)
      throw new Error("XOF is not enabled");
    return this.writeInto(t);
  }
  xof(t) {
    return V(t), this.xofInto(new Uint8Array(t));
  }
  digestInto(t) {
    if (Me(t, this), this.finished)
      throw new Error("digest() was already called");
    this.writeInto(t.length === this.outputLen ? t : t.subarray(0, this.outputLen)), this.destroy();
  }
  digest() {
    const t = new Uint8Array(this.outputLen);
    return this.digestInto(t), t;
  }
  destroy() {
    this.destroyed = !0, lt(this.state);
  }
  _cloneInto(t) {
    const { blockLen: n, suffix: r, outputLen: o, rounds: i, enableXOF: s } = this;
    return t || (t = new en(n, r, o, s, i)), t.blockLen = n, t.state32.set(this.state32), t.pos = this.pos, t.posOut = this.posOut, t.finished = this.finished, t.rounds = i, t.suffix = r, t.outputLen = o, t.enableXOF = s, t.canXOF = this.canXOF, t.destroyed = this.destroyed, t;
  }
}
const qo = (e, t, n, r = {}) => ge(() => new en(t, e, n), r), Sr = /* @__PURE__ */ qo(1, 136, 32), Qt = 2147483648, Nn = [
  {
    id: "bip44",
    label: "BIP44",
    /*
     * The exported key sits at the *fourth* level — the account's external chain — so the
     * addresses it produces are its own children: `xpub/i`, i = 0, 1, 2, 3…
     *
     * The third level (`m/44'/60'/0'`) would also work, and is what an earlier version
     * exported. Two reasons to move down one level:
     *
     *  - **It exposes strictly less.** The fourth-level key cannot derive the change chain
     *    (`/1/i`) or anything else the third level could; it is exactly the subtree the user
     *    sees and nothing else.
     *  - **It makes the convention unmistakable.** One key, and "add an account" increments
     *    the last index — which is what MetaMask, OKX Web3, Trust Wallet and imToken do, and
     *    therefore what a user's other wallet will agree with.
     *
     * `changeTemplate` is null because the change chain is genuinely unreachable from here.
     * That costs nothing on EVM, where change addresses are not a thing, and it is honest
     * about what this key can and cannot do.
     */
    xpubPath: "m/44'/60'/{account}'/0",
    receiveTemplate: "m/44'/60'/{account}'/0/{index}",
    changeTemplate: null,
    note: "MetaMask、OKX Web3、Trust Wallet、imToken 默认路径"
  }
];
function jo(e) {
  const t = Nn.find((n) => n.id === e);
  if (!t)
    throw new ut("PATH_INVALID", `unknown derivation scheme: ${e}`, {
      available: Nn.map((n) => n.id)
    });
  return t;
}
function Fn(e, t, n = 0) {
  return e.replace("{account}", String(t)).replace("{index}", String(n));
}
function Yo(e) {
  const t = e.trim();
  if (t === "m" || t === "M" || t === "") return [];
  if (!/^m(\/|$)/u.test(t))
    throw new ut("PATH_INVALID", `path must start with m/: ${e}`);
  const n = t.replace(/^m\/?/u, "");
  return n.length === 0 ? [] : n.split("/").map((r) => {
    const o = r.endsWith("'") || r.endsWith("h") || r.endsWith("H"), i = o ? r.slice(0, -1) : r;
    if (!/^\d+$/u.test(i))
      throw new ut("PATH_INVALID", `invalid path segment "${r}" in ${e}`);
    const s = Number.parseInt(i, 10);
    if (s >= Qt)
      throw new ut("PATH_INVALID", `path segment ${r} exceeds the hardened range`);
    return o ? s + Qt : s;
  });
}
function Zo(e) {
  return e.length === 0 ? "m" : "m/" + e.map((t) => t >= Qt ? `${t - Qt}'` : String(t)).join("/");
}
function zo(e) {
  return e >= Qt;
}
function Xo(e, t) {
  const n = Yo(t);
  let r = e;
  for (const o of n) {
    if (zo(o) && !r.privateKey)
      throw new ut(
        "DERIVATION_HARDENED_NEEDS_PRIVATE",
        `cannot derive hardened child ${Zo([o])} from a public-only key`
      );
    r = r.deriveChild(o);
  }
  return r;
}
function Go(e) {
  if (e.length === 33) {
    const t = Ut.Point.fromBytes(e).toAffine();
    return Wo(t.x, t.y);
  }
  if (e.length === 65) {
    if (e[0] !== 4)
      throw new ut("KEY_MISSING_PRIVATE", "uncompressed public key must start with 0x04");
    return Or(e.subarray(1));
  }
  throw new ut("KEY_MISSING_PRIVATE", `unsupported public key length ${e.length}`);
}
function Or(e) {
  const t = Sr(e);
  return Vo(be(t.subarray(12)));
}
function Wo(e, t) {
  const n = new Uint8Array(64);
  return n.set(Dn(e), 0), n.set(Dn(t), 32), Or(n);
}
function Dn(e) {
  const t = new Uint8Array(32);
  let n = e;
  for (let r = 31; r >= 0; r--)
    t[r] = Number(n & 0xffn), n >>= 8n;
  if (n !== 0n) throw new ut("KEY_MISSING_PRIVATE", "coordinate does not fit in 32 bytes");
  return t;
}
function Vo(e) {
  const t = e.toLowerCase().replace(/^0x/u, "");
  if (!/^[0-9a-f]{40}$/u.test(t))
    throw new ut("TX_INVALID_FIELD", `not an EVM address: ${e}`);
  const n = be(Sr(new TextEncoder().encode(t)));
  let r = "0x";
  for (let o = 0; o < 40; o++)
    r += Number.parseInt(n[o], 16) >= 8 ? t[o].toUpperCase() : t[o];
  return r;
}
BigInt(Number.MAX_SAFE_INTEGER);
function Jo(e, t, n, r, o) {
  const i = jo(t), s = vt.fromExtendedKey(e), c = Fn(i.receiveTemplate, n, r), a = o != null ? o : Fn(i.xpubPath, n), f = c.slice(a.length).replace(/^\//u, ""), d = f.length === 0 ? s : Xo(s, `m/${f}`);
  return {
    account: n,
    scheme: t,
    address: Go(d.publicKey),
    path: c,
    xpub: e
  };
}
const X = {
  userRejected: { code: 4001, message: "用户拒绝了请求" },
  unauthorized: { code: 4100, message: "该账户未被授权给此站点" },
  unsupportedMethod: { code: 4200, message: "NetProof Companion 不支持该方法" },
  disconnected: { code: 4900, message: "未连接硬件钱包" },
  chainDisconnected: { code: 4901, message: "当前链未连接" },
  unrecognizedChain: { code: 4902, message: "未知的链 ID" },
  internal: { code: -32603, message: "内部错误" },
  invalidParams: { code: -32602, message: "参数无效" },
  deviceRejected: { code: 4001, message: "硬件钱包拒绝了签名" }
};
class z extends Error {
  constructor({ code: n, message: r, data: o }) {
    super(r);
    l(this, "code");
    l(this, "data");
    this.name = "RpcError", this.code = n, o !== void 0 && (this.data = o);
  }
  /** The structured-clone-safe representation. */
  toShape() {
    return {
      code: this.code,
      message: this.message,
      ...this.data !== void 0 ? { data: this.data } : {}
    };
  }
}
const ke = {
  chainId: 1,
  rpcUrls: {
    1: "https://ethereum-rpc.publicnode.com",
    10: "https://mainnet.optimism.io",
    56: "https://bsc-dataseed.binance.org",
    137: "https://polygon-bor-rpc.publicnode.com",
    8453: "https://mainnet.base.org",
    42161: "https://arb1.arbitrum.io/rpc",
    43114: "https://api.avax.network/ext/bc/C/rpc",
    11155111: "https://ethereum-sepolia-rpc.publicnode.com",
    // Solana is not an EVM chain: different JSON-RPC methods (getBalance returns
    // lamports), different address format, 9 decimals. It lives here because the user
    // experiences it as "another network in the picker".
    // NOT `api.mainnet-beta.solana.com`: that endpoint answers HTTP 403 to any request
    // carrying an `Origin` header, which is every request a browser makes. Verified by
    // sending the same JSON-RPC call with and without `Origin` — 200 without, 403 with.
    // PublicNode answers both and sends `access-control-allow-origin: *`.
    501: "https://solana-rpc.publicnode.com"
  },
  accountIndex: 0,
  schemeId: "bip44",
  addressIndex: 0,
  addressCount: 20,
  visibleAccounts: 1,
  accountNames: {},
  hiddenAccounts: [],
  qrFragmentLength: 300,
  qrFrameDurationMs: 420,
  autoBroadcast: !0
}, Qo = 501;
function ts(e) {
  return e === Qo;
}
const de = "netproof.companion.", it = {
  wallets: `${de}wallets.v1`,
  settings: `${de}settings.v1`,
  origins: `${de}origins.v1`,
  pending: `${de}pending.v1`
}, Lt = {
  wallet: "netproof.wallet.v1",
  settings: "netproof.settings.v1",
  origins: "netproof.origins.v1",
  pending: "netproof.pending.v1"
};
function Kt(e) {
  if (typeof e != "string") return e != null ? e : null;
  try {
    return JSON.parse(e);
  } catch {
    return null;
  }
}
function Ht(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
function es(e) {
  if (!Object.values(Lt).some((s) => {
    const c = e.getItem(s);
    return c != null;
  })) return !1;
  const n = Kt(e.getItem(Lt.wallet));
  if (Ht(n) && typeof n.masterFingerprint == "string") {
    const s = n.masterFingerprint, c = Kt(e.getItem(it.wallets)), a = Ht(c) && Array.isArray(c.wallets) ? [...c.wallets] : [];
    if (!a.some((w) => Ht(w) && w.id === s)) {
      const w = Ht(n.device) ? n.device : {};
      a.push({
        ...n,
        id: s,
        // A name is required by the account list, and the old record had none: the device's
        // own name is the honest default, and re-pairing will keep whatever the user types.
        name: typeof w.name == "string" && w.name.length > 0 ? w.name : "硬件钱包",
        pairedAt: typeof n.pairedAt == "number" ? n.pairedAt : Date.now(),
        accountIndex: 0,
        addressIndex: 0,
        visibleAccounts: ke.visibleAccounts,
        hiddenAccounts: []
      });
    }
    const d = Ht(c) && typeof c.activeId == "string" ? c.activeId : s;
    e.setItem(it.wallets, JSON.stringify({ wallets: a, activeId: d }));
  }
  const r = Kt(e.getItem(Lt.settings)), o = e.getItem(it.settings);
  Ht(r) && o == null && e.setItem(it.settings, JSON.stringify(r));
  const i = Kt(e.getItem(Lt.origins));
  if (Array.isArray(i)) {
    const s = Kt(e.getItem(it.origins)), c = new Set(Array.isArray(s) ? s : []);
    for (const a of i) typeof a == "string" && c.add(a);
    e.setItem(it.origins, JSON.stringify([...c]));
  }
  for (const s of Object.values(Lt)) e.removeItem(s);
  return !0;
}
const ns = 200;
function rs(e) {
  var t;
  return ((t = e.addresses) != null ? t : []).map((n, r) => ({
    address: n.address,
    path: n.path,
    scheme: "solana",
    account: r,
    index: 0
  }));
}
function is(e, t, n, r) {
  const o = e.accounts.find(
    (c) => c.scheme === t && c.account === n
  );
  if (!o) return [];
  const i = Math.max(1, Math.min(r, ns)), s = [];
  for (let c = 0; c < i; c++)
    try {
      const a = Jo(
        o.xpub,
        o.scheme,
        o.account,
        c,
        o.xpubPath
      );
      s.push({
        address: a.address,
        path: a.path,
        scheme: o.scheme,
        account: o.account,
        index: c
      });
    } catch {
      break;
    }
  return s;
}
function Tr(e, t) {
  return ts(t.chainId) ? rs(e).slice(t.accountIndex, t.accountIndex + 1) : is(
    e,
    t.schemeId,
    t.accountIndex,
    t.addressCount
  );
}
function Cr(e, t) {
  var r, o;
  const n = Tr(e, t);
  return (o = (r = n[t.addressIndex]) != null ? r : n[0]) != null ? o : null;
}
class os {
  constructor(t) {
    l(this, "id", 0);
    l(this, "url");
    l(this, "timeoutMs");
    var n;
    this.url = t.url, this.timeoutMs = (n = t.timeoutMs) != null ? n : 2e4;
  }
  async call(t, n = []) {
    const r = new AbortController(), o = setTimeout(() => r.abort(), this.timeoutMs);
    try {
      const i = await fetch(this.url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", id: ++this.id, method: t, params: n }),
        signal: r.signal
      });
      if (!i.ok)
        throw new z({
          code: X.internal.code,
          message: `RPC 节点返回 HTTP ${i.status}`
        });
      const s = await i.json();
      if (s.error)
        throw new z({
          code: s.error.code,
          message: s.error.message,
          ...s.error.data !== void 0 ? { data: s.error.data } : {}
        });
      return s.result;
    } catch (i) {
      throw i instanceof z ? i : i.name === "AbortError" ? new z({ code: X.internal.code, message: "RPC 请求超时" }) : new z({
        code: X.internal.code,
        message: `无法连接 RPC 节点：${i.message}`
      });
    } finally {
      clearTimeout(o);
    }
  }
}
function qt(e, t) {
  if (typeof e != "string" || !/^0x[0-9a-fA-F]+$/u.test(e))
    throw new z({
      code: X.internal.code,
      message: `RPC 节点返回的 ${t} 不是合法的十六进制数量：${String(e)}`
    });
  return e;
}
async function ss(e, t, n) {
  const r = new os({ url: n.rpcUrl });
  switch (e) {
    case "eth_getTransactionCount":
      return qt(await r.call(e, t), "nonce");
    case "eth_gasPrice":
      return qt(await r.call(e, t), "gasPrice");
    case "eth_estimateGas":
      return qt(await r.call(e, t), "gas");
    case "eth_maxPriorityFeePerGas": {
      const o = await r.call(e, t);
      return typeof o == "string" ? qt(o, "maxPriorityFeePerGas") : qt(await r.call("eth_gasPrice", []), "gasPrice");
    }
    case "eth_chainId": {
      const o = await r.call(e, t);
      return typeof o == "string" ? o : `0x${n.chainId.toString(16)}`;
    }
    case "eth_sendRawTransaction":
      return cs(t[0]), r.call(e, t);
    default:
      return r.call(e, t);
  }
}
function cs(e) {
  if (typeof e != "string" || !/^0x02[0-9a-fA-F]+$|^0x[0-9a-fA-F]{100,}$/u.test(e))
    throw new z({
      code: X.invalidParams.code,
      message: "拒绝广播：不是合法的已签名交易载荷"
    });
}
const as = /* @__PURE__ */ new Set([
  "eth_blockNumber",
  "eth_call",
  "eth_chainId",
  "eth_estimateGas",
  "eth_feeHistory",
  "eth_gasPrice",
  "eth_getBalance",
  "eth_getBlockByNumber",
  "eth_getCode",
  "eth_getLogs",
  "eth_getStorageAt",
  "eth_getTransactionByHash",
  "eth_getTransactionCount",
  "eth_getTransactionReceipt",
  "eth_maxPriorityFeePerGas",
  "eth_sendRawTransaction",
  "net_version",
  "web3_clientVersion"
]), fs = {
  eth_sendTransaction: "sendTransaction",
  eth_signTransaction: "signTransaction",
  personal_sign: "personal_sign",
  eth_signTypedData_v4: "signTypedData",
  eth_signTypedData: "signTypedData"
};
async function ds(e, t, n) {
  try {
    return { result: await us(e, t, n) };
  } catch (r) {
    return r instanceof z ? { error: r.toShape() } : { error: { code: X.internal.code, message: r.message } };
  }
}
async function us(e, t, n) {
  var a;
  const { wallet: r, settings: o, origin: i, approvedOrigins: s } = n;
  switch (e) {
    case "eth_chainId":
      return `0x${o.chainId.toString(16)}`;
    case "net_version":
      return String(o.chainId);
    case "wallet_getPermissions":
      return s.includes(i) ? [{ parentCapability: "eth_accounts", caveats: [] }] : [];
    /*
     * EIP-2255: a wallet that answers `wallet_requestPermissions` is expected to answer
     * `wallet_getPermissions` too, and connectors do check it after connecting. Answering
     * with an unsupported-method error where a permission list is expected is the difference
     * between "connected" and "nothing happened".
     */
    case "wallet_getPermissions":
      return s.includes(i) ? [{ parentCapability: "eth_accounts", caveats: [] }] : [];
    /*
     * EIP-5792: `{}` means "no optional capabilities". Saying so explicitly is better than an
     * unsupported-method error, because a connector that asks is deciding whether to use
     * batched calls, and "no" is a legitimate answer it can fall back from.
     */
    case "wallet_getCapabilities":
      return {};
    case "wallet_requestPermissions":
      return kn(r), [
        {
          parentCapability: "eth_accounts",
          caveats: [{ type: "restrictReturnedAccounts", value: [(a = Cr(r, o)) == null ? void 0 : a.address] }]
        }
      ];
    case "wallet_revokePermissions":
      return null;
    case "wallet_switchEthereumChain": {
      const f = hs(t[0]);
      if (f === o.chainId) return null;
      if (!o.rpcUrls[f]) throw new z(X.unrecognizedChain);
      return await n.requestApproval({
        id: ue(),
        kind: "connect",
        origin: i,
        chainId: f,
        createdAt: Date.now(),
        method: "wallet_switchEthereumChain",
        params: t
      }), null;
    }
    case "wallet_addEthereumChain":
      throw new z({
        code: X.unsupportedMethod.code,
        message: "出于安全考虑，NetProof Companion 不接受 dApp 添加网络，请在插件设置中添加 RPC。"
      });
    case "eth_accounts":
      return !r || !s.includes(i) ? [] : $e(r, o);
    case "eth_requestAccounts": {
      if (!r)
        throw await n.requestApproval({
          id: ue(),
          kind: "connect",
          origin: i,
          chainId: o.chainId,
          createdAt: Date.now(),
          method: e,
          params: []
        }), new z(X.disconnected);
      return s.includes(i) || await n.requestApproval({
        id: ue(),
        kind: "connect",
        origin: i,
        chainId: o.chainId,
        createdAt: Date.now(),
        method: e,
        params: []
      }), $e(r, o);
    }
  }
  if (as.has(e))
    return n.forward(e, t);
  const c = fs[e];
  if (c) {
    kn(r), ls(i, s);
    const f = {
      id: ue(),
      kind: c,
      origin: i,
      chainId: o.chainId,
      createdAt: Date.now(),
      method: e,
      params: t
    };
    return n.requestApproval(f);
  }
  throw e.startsWith("wallet_") ? new z(X.unsupportedMethod) : new z({ code: -32601, message: `不支持的方法 ${e}` });
}
function $e(e, t) {
  const n = new Set(t.hiddenAccounts.map((i) => i.toLowerCase())), r = Tr(e, t).filter(
    (i) => !n.has(i.address.toLowerCase())
  ), o = Cr(e, t);
  return o ? [o.address, ...r.map((i) => i.address).filter((i) => i !== o.address)] : [];
}
function kn(e) {
  if (!e)
    throw new z({
      code: X.disconnected.code,
      message: "尚未连接硬件钱包。请在插件中扫码导入 xpub。"
    });
}
function ls(e, t) {
  if (!t.includes(e))
    throw new z({
      code: X.unauthorized.code,
      message: "该站点尚未获得账户授权。请先调用 eth_requestAccounts。"
    });
}
function hs(e) {
  const t = e == null ? void 0 : e.chainId;
  if (typeof t == "string") return Number.parseInt(t.replace(/^0x/u, ""), 16);
  if (typeof t == "number") return t;
  throw new z(X.invalidParams);
}
function ue() {
  const e = new Uint8Array(16);
  return crypto.getRandomValues(e), be(e, !0);
}
const Hr = it.wallets, ps = it.settings, Lr = it.origins, nn = it.pending;
function Xt() {
  return chrome.storage.local;
}
let jt = null;
function xe() {
  return jt != null || (jt = (async () => {
    try {
      const e = Object.values(Lt), t = await Xt().get(e), n = {}, r = [];
      if (!es({
        getItem: (i) => t[i],
        setItem: (i, s) => {
          n[i] = s;
        },
        removeItem: (i) => r.push(i)
      })) return;
      r.length > 0 && await Xt().remove(r), Object.keys(n).length > 0 && await Xt().set(n);
    } catch {
    }
  })()), jt;
}
async function te(e) {
  const n = (await Xt().get(e))[e];
  if (typeof n != "string") return null;
  try {
    return JSON.parse(n);
  } catch {
    return null;
  }
}
async function rn(e, t) {
  await Xt().set({ [e]: JSON.stringify(t) });
}
async function on() {
  var t, n;
  await xe();
  const e = await te(Hr);
  return !e || !Array.isArray(e.wallets) ? null : (n = (t = e.wallets.find((r) => r.masterFingerprint === e.activeId)) != null ? t : e.wallets[0]) != null ? n : null;
}
async function Ee() {
  var r, o, i, s, c, a, f, d;
  await xe();
  const e = await te(ps), t = await te(
    Hr
  ), n = (i = (r = t == null ? void 0 : t.wallets) == null ? void 0 : r.find((w) => w.masterFingerprint === t.activeId)) != null ? i : (o = t == null ? void 0 : t.wallets) == null ? void 0 : o[0];
  return {
    ...ke,
    ...e != null ? e : {},
    rpcUrls: { ...ke.rpcUrls, ...(s = e == null ? void 0 : e.rpcUrls) != null ? s : {} },
    ...n ? {
      accountIndex: (c = n.accountIndex) != null ? c : 0,
      addressIndex: (a = n.addressIndex) != null ? a : 0,
      visibleAccounts: (f = n.visibleAccounts) != null ? f : 1,
      hiddenAccounts: (d = n.hiddenAccounts) != null ? d : []
    } : {}
  };
}
async function sn() {
  var e;
  return await xe(), (e = await te(Lr)) != null ? e : [];
}
async function Ur(e) {
  const t = await sn();
  t.includes(e) || await rn(Lr, [...t, e]);
}
async function Rt() {
  var e;
  return await xe(), (e = await te(nn)) != null ? e : [];
}
async function ws(e) {
  const t = await Rt();
  await rn(
    nn,
    [...t.filter((n) => n.id !== e.id), e]
  );
}
async function Nr(e) {
  var n;
  return (n = (await Rt()).find((r) => r.id === e)) != null ? n : null;
}
async function cn(e) {
  const t = await Rt();
  await rn(
    nn,
    t.filter((n) => n.id !== e)
  );
}
const $n = "tab.html", Bt = /* @__PURE__ */ new Map(), Fr = /* @__PURE__ */ new Map(), gs = /* @__PURE__ */ new WeakMap(), le = [], bs = 40;
function Mn(e, t, n) {
  le.unshift({ at: Date.now(), method: e, origin: t, outcome: n }), le.length = Math.min(le.length, bs);
}
chrome.runtime.onInstalled.addListener(() => {
  Rt().then(async (e) => {
    for (const t of e) await cn(t.id);
  });
});
chrome.runtime.onConnect.addListener((e) => {
  e.name === "netproof-provider" && e.onMessage.addListener((t) => {
    (async () => {
      var n;
      try {
        if (t.type === "approval-result") {
          Dr(t);
          return;
        }
        if (t.type === "provider-poke") {
          e.postMessage({ type: "poked" });
          return;
        }
        if (t.type !== "rpc") return;
        Fr.set(t.origin, e), gs.set(e, t.origin);
        const r = await ys(t.method, t.params, t.origin);
        e.postMessage({ type: "rpc-result", id: t.id, ...r });
      } catch (r) {
        e.postMessage({
          type: "rpc-result",
          id: (n = t.id) != null ? n : "unknown",
          error: { code: X.internal.code, message: r.message }
        });
      }
    })();
  });
});
chrome.runtime.onMessage.addListener((e, t, n) => {
  const r = e;
  return (r == null ? void 0 : r.type) === "approval-result" ? (Dr(r), n({ ok: !0 }), !0) : (r == null ? void 0 : r.type) === "pending-list" ? (Rt().then((o) => n({ pending: o })), !0) : (r == null ? void 0 : r.type) === "diagnostics" ? ((async () => {
    var a, f;
    const [o, i, s, c] = await Promise.all([
      Rt(),
      on(),
      Ee(),
      sn()
    ]);
    n({
      wallet: (a = i == null ? void 0 : i.masterFingerprint) != null ? a : null,
      chainId: s.chainId,
      rpcUrl: (f = s.rpcUrls[s.chainId]) != null ? f : null,
      approvedOrigins: c,
      pending: o.map((d) => ({ id: d.id, method: d.method, origin: d.origin })),
      decisions: le
    });
  })(), !0) : !1;
});
async function ys(e, t, n) {
  const r = await Ee(), o = await on(), i = await sn(), s = r.rpcUrls[r.chainId];
  return s ? (o ? i.includes(n) || Mn(e, n, "未授权来源") : Mn(e, n, "还没有配对的钱包"), ds(e, t, {
    wallet: o,
    settings: r,
    origin: n,
    approvedOrigins: i,
    forward: (c, a) => ss(c, a, { rpcUrl: s, chainId: r.chainId }),
    requestApproval: (c) => ms(c)
  })) : { error: { code: X.unrecognizedChain.code, message: `链 ${r.chainId} 没有配置 RPC` } };
}
function ms(e, t) {
  return new Promise((n, r) => {
    (async () => (await ws(e), Bt.set(e.id, { resolve: n, reject: r }), await we(1), await Es(e), setTimeout(() => {
      Bt.has(e.id) && (Bt.delete(e.id), cn(e.id), we(0), r({ code: X.userRejected.code, message: "请求已超时，请重新发起" }));
    }, 600 * 1e3)))();
  });
}
function xs() {
  Rt().then((e) => we(e.length));
}
async function we(e) {
  try {
    await chrome.action.setBadgeBackgroundColor({ color: "#2b6bff" }), await chrome.action.setBadgeText({ text: e > 0 ? String(e) : "" });
  } catch {
  }
}
async function Es(e) {
  if (e.kind === "connect")
    try {
      const t = chrome.action;
      if (typeof t.openPopup == "function") {
        await t.openPopup();
        return;
      }
    } catch {
    }
  await vs(e.id);
}
async function vs(e) {
  const t = chrome.runtime.getURL(`${$n}#/sign/${e}`), r = (await chrome.tabs.query({ url: chrome.runtime.getURL(`${$n}*`) }))[0];
  if ((r == null ? void 0 : r.id) !== void 0) {
    await chrome.tabs.update(r.id, { url: t, active: !0 }), r.windowId !== void 0 && await chrome.windows.update(r.windowId, { focused: !0 });
    return;
  }
  await chrome.tabs.create({ url: t });
}
async function Dr(e) {
  var r;
  const t = Bt.get(e.id);
  if (!t) return;
  const n = await Nr(e.id);
  Bt.delete(e.id), we(0), n && (an = n.origin), n && !e.error && await Ur(n.origin), e.error ? t.reject(e.error) : t.resolve(e.result), As(e, (r = n == null ? void 0 : n.origin) != null ? r : null);
}
async function As(e, t) {
  if (e.error) return;
  const n = t != null ? t : an, r = n ? Fr.get(n) : void 0;
  if (!n || !r) return;
  const o = await on();
  if (!o) return;
  const i = await Ee();
  try {
    r.postMessage({
      type: "event",
      event: "accountsChanged",
      data: $e(o, i)
    });
  } catch {
  }
}
let an = null;
async function Bs(e, t) {
  const n = await Nr(e);
  if (!n) return;
  an = n.origin, await cn(e), xs();
  const r = Bt.get(e);
  r && (Bt.delete(e), t.error ? r.reject(t.error) : r.resolve(t.result));
}
async function Is(e) {
  await Ur(e);
}
async function Rs() {
  return Ee();
}
function Ss() {
  const e = new Uint8Array(16);
  return crypto.getRandomValues(e), be(e, !0);
}
export {
  z as RpcError,
  Bs as __completeApproval,
  Bs as completeApproval,
  Ss as newRequestId,
  Rs as readSettings,
  Is as rememberOrigin
};
